"""Browser bridge for the D2 Survivors Save Editor web DEMO (runs in Pyodide).

Everything game-related comes from d2s_core - the same code, tables and tests as the Windows editor.
Every function takes/returns plain JSON-able values; the page calls them through Pyodide.
DEMO: only gold can be changed here; item, skill and belt editing are in the full version (Discord).
"""
from __future__ import annotations

import json

from d2s_core import codec
from d2s_core.build_check import BuildRules
from d2s_core.charsi import GOLD_CAP, MAX_EXTRA, Charsi
from d2s_core.destinations import stash_list  # noqa: F401  (kept for parity with the desktop editor)
from d2s_core.itemgen import ItemFactory
from d2s_core.itemgen.describe import Describer
from d2s_core.itemtext import ItemText
from d2s_core.legit import LegitCheck
from d2s_core.modtext import ModText
from d2s_core.records import record_problems
from d2s_core.save_items import iter_save_items
from d2s_core.tooltip import GameTooltip

CLASSES = ("amazon", "assassin", "barbarian", "druid", "necromancer", "paladin", "sorceress")
SLOTS = ("head", "amulet", "body", "weapon", "shield", "gloves", "ring1", "ring2", "belt", "boots")
CATEGORIES = [("head", "Helms"), ("amulet", "Amulets"), ("body", "Body Armor"), ("shield", "Shields"),
              ("gloves", "Gloves"), ("belt", "Belts"), ("boots", "Boots"), ("ring", "Rings"), ("axe", "Axes"),
              ("sword", "Swords"), ("mace", "Maces"), ("scepter", "Scepters"), ("dagger", "Daggers"),
              ("throwing", "Throwing Weapons"), ("javelin", "Javelins"), ("spear", "Spears"), ("polearm", "Polearms"),
              ("bow", "Bows"), ("crossbow", "Crossbows"), ("staff", "Staves"), ("wand", "Wands"), ("orb", "Orbs"),
              ("claw", "Katars"), ("charm", "Charms")]
CAT_LABEL = dict(CATEGORIES)
SLOT_LABEL = {"weapon": "in a weapon", "helm": "in a helm or body armor", "shield": "in a shield"}


class _State:
    def __init__(self):
        self.f = ItemFactory()
        gd = self.f.gd
        self.gd = gd
        self.tables = json.loads(gd.tables_path.read_text(encoding="utf-8"))
        self.tooltip = GameTooltip(self.tables, gd.R, self.f)     # 10.8: Required Level (game 2026.1102.1)
        self.modtext = ModText(self.tables)
        self.itemtext = ItemText(gd.R)
        self.legit = LegitCheck(self.f, self.tables)
        self.describer = Describer(self.f)
        self.builds = BuildRules(self.tables) if "skills_active" in self.tables else None
        self.charsi = Charsi(self.tables.get("charsi") or [])
        self.data = None
        self.original = None
        self.original_code = ""
        self._ref = None


S: _State | None = None


def _j(x) -> str:
    return json.dumps(x, ensure_ascii=False, default=str)


def init() -> str:
    global S
    S = _State()
    return _j({"game_version": S.gd.game_version, "gold_cap": GOLD_CAP,
               "wares": [{"key": w["key"], "name": w["name"]} for w in S.charsi.wares]})


# ---------------------------------------------------------------------------------------------- save
def load(text: str) -> str:
    text = (text or "").strip()
    if not text:
        raise ValueError("Paste a save code (it starts with D2S1:) or choose a save file.")
    if text.startswith("{"):
        data = json.loads(text)                     # a save.json from %APPDATA%\D2 Survivors\save
        code = codec.encode_save(data)
    else:
        if not text.startswith(codec.PREFIX):
            raise ValueError("This is not a D2 Survivors save code: it must start with D2S1:")
        data = codec.decode_save(text)
        code = text
    if not isinstance(data, dict) or not isinstance(data.get("version"), (int, float)):
        raise ValueError("The save could not be read (no version number).")
    S.data = data
    S.original = codec.deep_copy(data)
    S.original_code = code
    return summary()


def _heroes():
    d = S.data
    names = set()
    for key in ("heroes", "equippedByClass", "inventoryByClass", "charmsByClass", "unlocked", "mercs"):
        v = d.get(key)
        if isinstance(v, dict):
            for cls, val in v.items():
                if cls in CLASSES and val:
                    names.add(cls)
    out = []
    for cls in CLASSES:
        if cls not in names:
            continue
        hero = (d.get("heroes") or {}).get(cls) or {}
        kept = hero.get("kept") if isinstance(hero.get("kept"), dict) else {}
        run = hero.get("run") if isinstance(hero.get("run"), dict) else {}
        src = run or kept
        build = src.get("build") if isinstance(src.get("build"), dict) else {}
        level = build.get("level") or ((src.get("run") or {}).get("level") if isinstance(src.get("run"), dict) else None)
        eq = (d.get("equippedByClass") or {}).get(cls) or {}
        inv = (d.get("inventoryByClass") or {}).get(cls) or []
        ch = (d.get("charmsByClass") or {}).get(cls) or []
        merc = (d.get("mercs") or {}).get(cls) or {}
        hired = merc.get("hired") if isinstance(merc, dict) else {}
        mercs = []
        for mt, m in (hired or {}).items():
            if isinstance(m, dict):
                mercs.append({"type": mt, "active": merc.get("active") == mt,
                              "items": len([x for x in (m.get("worn") or {}).values() if isinstance(x, dict)]),
                              "picks": m.get("picks") or []})
        out.append({"cls": cls, "level": level, "difficulty": src.get("difficulty") or (d.get("unlocked") or {}).get(cls),
                    "act": src.get("act"), "in_run": bool(run), "equipped": len([x for x in eq.values() if isinstance(x, dict)]),
                    "inventory": len(inv), "charms": len(ch), "mercs": mercs,
                    "skills": [(s.get("id"), s.get("level")) for s in build.get("skills") or [] if isinstance(s, dict)]})
    return out


def summary() -> str:
    d = S.data
    lb = d.get("leaderboard") if isinstance(d.get("leaderboard"), dict) else {}
    return _j({"gold": int(d.get("gold", 0) or 0), "mode": "Hardcore" if d.get("mode") == "hc" else "Softcore",
               "version": d.get("version"), "nickname": lb.get("name") or "", "edited": bool(lb.get("edited")),
               "heroes": _heroes(), "items": sum(1 for _ in iter_save_items(d)),
               "changes": len(_changes())})


# ---------------------------------------------------------------------------------------------- items
def _status(item):
    probs = record_problems(item, S.gd)
    if probs:
        return "bad", "UNREADABLE: the game drops this item when it loads the save (" + "; ".join(probs) + ")"
    fault = S.legit.check(item)
    if fault:
        return "bad", f"NOT LEGIT: {fault['why']} (red border in game)"
    try:
        ver = S.f.verify(item)
    except Exception:
        ver = None
    if ver is True:
        return "ok", "LEGIT: regenerates exactly from its roll"
    if ver is False:
        return "bad", "NOT LEGIT: differs from what its roll makes (red border in game)"
    return "ok", "LEGIT: no roll, inside the game's ranges"


def _card(item, where, path):
    try:
        lines = S.tooltip.lines(item)
    except Exception as exc:  # never break the page on one odd item
        lines = [(f"(tooltip unavailable: {exc})", "implicit")]
    kind, text = _status(item)
    roll = item.get("roll")
    meta = []
    if isinstance(roll, list) and len(roll) >= 3:
        meta.append(f"Roll: seed {roll[1]} · item level {roll[2]}")
    else:
        meta.append("No roll")
    if item.get("level"):
        meta.append(f"Level {item['level']}")
    if item.get("ethereal"):
        meta.append("Ethereal")
    return {"path": path, "where": where, "name": item.get("name") or item.get("base") or "?",
            "base": item.get("base") or "", "rarity": item.get("rarity") or "normal", "type": item.get("type") or "",
            "lines": lines, "status": kind, "status_text": text, "meta": " · ".join(meta),
            "sockets": len(item.get("socketed") or []) if isinstance(item.get("socketed"), list) else None}


def hero_items(cls: str) -> str:
    d = S.data
    groups = []
    eq = (d.get("equippedByClass") or {}).get(cls) or {}
    order = list(SLOTS) + [k for k in eq if k not in SLOTS]
    # game 2026.1102.1: a second weapon set; the set in hand is in equippedByClass, the other in weaponSets
    other = ((d.get("weaponSets") or {}).get(cls) or {}) if isinstance(d.get("weaponSets"), dict) else {}
    act = 2 if isinstance(other, dict) and other.get("active") == 2 else 1
    two = isinstance(other, dict) and any(isinstance(other.get(s), dict) for s in ("weapon", "shield"))

    def where(s, mine):
        if not two or s not in ("weapon", "shield"):
            return s
        n = act if mine else (2 if act == 1 else 1)
        return f"{s} (set {'I' if n == 1 else 'II'}{', in hand' if mine else ''})"
    rows = [_card(eq[s], where(s, True), ["equippedByClass", cls, s]) for s in order if isinstance(eq.get(s), dict)]
    if two:
        rows += [_card(other[s], where(s, False), ["weaponSets", cls, s]) for s in ("weapon", "shield")
                 if isinstance(other.get(s), dict)]
    groups.append({"title": "Equipped", "items": rows})
    inv = (d.get("inventoryByClass") or {}).get(cls) or []
    groups.append({"title": "Inventory", "items": [_card(it, f"inventory {i + 1}", ["inventoryByClass", cls, i])
                                                    for i, it in enumerate(inv) if isinstance(it, dict)]})
    ch = (d.get("charmsByClass") or {}).get(cls) or []
    groups.append({"title": "Charms", "items": [_card(it, f"charm {i + 1}", ["charmsByClass", cls, i])
                                                 for i, it in enumerate(ch) if isinstance(it, dict)]})
    merc = (d.get("mercs") or {}).get(cls) or {}
    for mt, m in ((merc.get("hired") or {}) if isinstance(merc, dict) else {}).items():
        worn = (m or {}).get("worn") or {}
        groups.append({"title": f"Mercenary · {mt.title()}" + (" (active)" if merc.get("active") == mt else ""),
                       "items": [_card(it, s, ["mercs", cls, "hired", mt, "worn", s]) for s, it in worn.items()
                                 if isinstance(it, dict)]})
    return _j(groups)


def stash() -> str:
    d = S.data
    groups = []
    for tab, items in (d.get("stashTabs") or {}).items():
        if not isinstance(items, list):
            continue
        title = ("Shared stash " + tab[6:]) if tab.startswith("shared") else f"Personal stash · {tab.title()}"
        groups.append({"title": title, "items": [_card(it, f"slot {i + 1}", ["stashTabs", tab, i])
                                                 for i, it in enumerate(items) if isinstance(it, dict)]})
    uq = d.get("uniques") or []
    if uq:
        groups.append({"title": "Uniques tab", "items": [_card(it, f"slot {i + 1}", ["uniques", i])
                                                          for i, it in enumerate(uq) if isinstance(it, dict)]})
    return _j(groups)


def _at(path):
    node = S.data
    for p in path:
        node = node[p]
    return node


def item_detail(path_json: str) -> str:
    item = _at(json.loads(path_json))
    rows, notes = S.describer.rows(item)
    stats = item.get("stats") or []
    out = []
    for row in rows:
        shown = ""
        try:
            if row["where"] == "stats" and row["index"] < len(stats):
                conv = S.f.uniques.display.convert_one(stats[row["index"]], stats)
                shown = ", ".join(S.modtext.line(m["stat"], m["value"], short=True) for m in conv)
            elif row["where"].startswith("bonus"):
                shown = S.itemtext.stat_line(row["stat"], row["value"], row.get("param")) + \
                    f"  ({int(row['where'].split(':')[1]) + 1} items)"
            elif row["where"] == "mods":
                shown = S.modtext.line(row["stat"], row["value"], short=True)
        except Exception:
            shown = ""
        if row["lo"] is None:
            rng = "unknown"
        elif row["lo"] == row["hi"]:
            rng = f"fixed {row['lo']}"
        else:
            rng = f"{row['lo']} … {row['hi']}"
        out.append({"stat": row["stat"] + (f" [{row['param']}]" if row.get("param") is not None else ""),
                    "shown": shown, "value": row["value"], "range": rng, "source": row.get("source", "")})
    return _j({"rows": out, "notes": notes, "raw": item})


# ---------------------------------------------------------------------------------------------- gold & charsi
def set_gold(value) -> str:
    try:
        n = int(str(value).replace(",", "").replace(" ", "").replace("_", ""))
    except ValueError:
        raise ValueError("Gold must be a whole number.") from None
    if n < 0:
        raise ValueError("Gold cannot be negative.")
    if n > GOLD_CAP:
        raise ValueError(f"The game accepts up to {GOLD_CAP:,} gold.")
    S.data["gold"] = n
    return summary()


def charsi() -> str:
    d = S.data
    rows = S.charsi.rows(d, d.get("mode") == "hc")
    spent = sum(r["spent"] for r in rows)
    rest = sum(r["to_max"] for r in rows)
    return _j({"rows": rows, "spent": spent, "to_max": rest, "gold": int(d.get("gold", 0) or 0), "max_extra": MAX_EXTRA})


def charsi_calc(key: str, want) -> str:
    d = S.data
    hc = bool(d and d.get("mode") == "hc")
    top = S.charsi.max_level(key, hc)
    w = S.charsi.by_key[key]
    have = min(S.charsi.level_of(d, key), top) if d else 0
    if top == 0:
        return _j({"text": f"{w['name']} is not sold in Hardcore.", "cost": 0, "have": have, "top": top})
    want = max(1, min(int(want), top))
    if want <= have:
        return _j({"text": f"{w['name']}: the save already has level {have} (of {top}).", "cost": 0, "have": have, "top": top})
    cost = S.charsi.cost_between(key, have, want)
    part = f"normal rank {want}" if want <= w["maxRank"] else f"extra rank {want - w['maxRank']}"
    gold = int(d.get("gold", 0) or 0) if d else 0
    msg = (f"{w['name']} from level {have} to {want} ({part}): {cost:,} gold. "
           f"Bonus {S.charsi.bonus_ranks(key, have):.2f} → {S.charsi.bonus_ranks(key, want):.2f} ranks.")
    if d is not None:
        msg += " You have enough gold." if gold >= cost else f" Missing {cost - gold:,} gold."
        if cost > GOLD_CAP:
            msg += f" More than the {GOLD_CAP:,} gold a save can hold: buy it in steps."
    return _j({"text": msg, "cost": cost if cost <= GOLD_CAP else 0, "have": have, "top": top})


def charsi_default_level(key: str) -> int:
    d = S.data
    have = S.charsi.level_of(d, key) if d else 0
    top = S.charsi.max_level(key)
    return min(top, have + 1)


# ---------------------------------------------------------------------------------------------- check save
def check_save() -> str:
    d = S.data
    ok = by_roll = by_range = 0
    rows = []
    for where, it in iter_save_items(d):
        probs = record_problems(it, S.gd)
        if probs:
            rows.append({"kind": "UNREADABLE", "where": where, "name": it.get("name"), "why": "; ".join(probs)})
            continue
        fault = S.legit.check(it)
        if fault:
            rows.append({"kind": "NOT LEGIT", "where": where, "name": it.get("name"), "why": fault["why"]})
            continue
        ok += 1
        if isinstance(it.get("roll"), list):
            by_roll += 1
        else:
            by_range += 1
    builds = [{"where": w, "why": p} for w, p in S.builds.check_save(d)] if S.builds else None
    gold = d.get("gold")
    return _j({"game_version": S.gd.game_version, "ok": ok, "by_roll": by_roll, "by_range": by_range, "rows": rows,
               "builds": builds, "gold_over": isinstance(gold, (int, float)) and gold > GOLD_CAP})


# ---------------------------------------------------------------------------------------------- reference
def _ref_rows():
    if S._ref is None:
        gd = S.gd
        rows = []
        for u in gd.uniques_list:
            b = gd.bases.get(u["base"]) or {}
            rows.append({"kind": "unique", "name": u["name"], "base": u["base"], "lvl": u.get("lvl"),
                         "cat": b.get("kind") or b.get("type") or "", "cls": b.get("cls")})
        for s in gd.sets_list:
            b = gd.bases.get(s["base"]) or {}
            rows.append({"kind": "set", "name": s["name"], "base": s["base"], "lvl": s.get("lvl"), "set": s.get("set"),
                         "cat": b.get("kind") or b.get("type") or "", "cls": b.get("cls")})
        for r in gd.runeword_list:
            rows.append({"kind": "runeword", "name": r["name"], "base": " ".join(r["runes"]), "lvl": r.get("lvl"),
                         "cat": "runeword", "cls": None})
        rows.sort(key=lambda r: r["name"].replace("The ", "", 1))
        R = gd.R
        for r in rows:
            if r["kind"] == "unique":
                lines = S.itemtext.lines((R.get("uniques", {}).get(r["name"]) or {}).get("props"))
            elif r["kind"] == "set":
                row = R.get("setItems", {}).get(r["name"]) or {}
                lines = S.itemtext.lines(row.get("props")) + [l for b in row.get("bonus") or [] for l in S.itemtext.lines(b)]
            else:
                lines = S.itemtext.lines((R.get("runewords", {}).get(r["name"]) or {}).get("props"))
            r["search"] = " ".join([r["name"], r["base"], r.get("set") or ""] + lines).casefold()
            r["catLabel"] = CAT_LABEL.get(r["cat"], "Runewords" if r["cat"] == "runeword" else r["cat"])
        S._ref = rows
    return S._ref


def reference_list() -> str:
    return _j([{k: r[k] for k in ("kind", "name", "base", "lvl", "cat", "catLabel", "cls", "search")} for r in _ref_rows()])


def reference_card(kind: str, name: str) -> str:
    gd, R, T = S.gd, S.gd.R, S.itemtext
    r = next(x for x in _ref_rows() if x["kind"] == kind and x["name"] == name)
    out = {"name": name, "kind": kind, "meta": [], "props": [], "sections": []}
    if kind == "runeword":
        rw = gd.runeword_defs.get(name) or {}
        row = R.get("runewords", {}).get(name) or {}
        bases = S.f.runewords.all_bases(name)
        slots = {}
        for b in bases:
            slots.setdefault(S.f.runewords.slot(b), []).append(b["name"])
        kinds = sorted({CAT_LABEL.get(b.get("kind") or b.get("type"), b.get("kind") or b.get("type")) for b in bases})
        out["meta"] = [f"Runeword · {' + '.join(rw.get('runes', []))} · needs item level {r.get('lvl')}+",
                       f"Bases: {', '.join(kinds)} ({len(bases)} base types)"]
        out["props"] = T.lines(row.get("props"))
        for slot in slots:
            runes = [p for rn in rw.get("runes", []) for p in (R.get("runes", {}).get(rn) or {}).get(slot, [])]
            lines = T.lines(runes)
            if lines:
                head = "From the runes " + SLOT_LABEL.get(slot, slot) if len(slots) > 1 else "From the runes"
                out["sections"].append({"title": head, "lines": lines, "kind": "prop"})
        return _j(out)
    b = gd.bases.get(r["base"]) or {}
    rb = R.get("bases", {}).get(r["base"]) or {}
    out["meta"].append(f"{'Unique' if kind == 'unique' else 'Set item'} · {r['base']} · {r['catLabel']}"
                       + (f" · {b['cls'].title()} only" if b.get("cls") else ""))
    meta = [f"Drops from item level {r['lvl']}"] if r.get("lvl") else []
    if rb.get("defense"):
        meta.append(f"Base defense {rb['defense'][0]}-{rb['defense'][1]}")
    if rb.get("level"):
        meta.append(f"Required level {rb['level']}+")
    if meta:
        out["meta"].append(" · ".join(meta))
    if kind == "unique":
        out["props"] = T.lines((R.get("uniques", {}).get(name) or {}).get("props"))
        return _j(out)
    row = R.get("setItems", {}).get(name) or {}
    out["props"] = T.lines(row.get("props"))
    bonus = [f"({n + 2} items) {l}" for n, grp in enumerate(row.get("bonus") or []) for l in T.lines(grp)]
    if bonus:
        out["sections"].append({"title": "With more items of the set worn", "lines": bonus, "kind": "bonus"})
    if r.get("set"):
        st = R.get("sets", {}).get(r["set"]) or {}
        members = [s["name"] for s in gd.sets_list if s.get("set") == r["set"]]
        lines = [f"({n + 2} items) {l}" for n, grp in enumerate(st.get("partial") or []) for l in T.lines(grp)]
        lines += [f"Full set: {l}" for l in T.lines(st.get("full"))]
        out["sections"].append({"title": r["set"], "sub": ", ".join(members), "lines": lines, "kind": "bonus"})
    return _j(out)


# ---------------------------------------------------------------------------------------------- export
def _fmt(v):
    s = json.dumps(v, ensure_ascii=False)
    return s if len(s) <= 80 else s[:77] + "…"


def _changes():
    if S.data is None or S.original is None:
        return []
    out = []
    for path in codec.changed_paths(S.original, S.data):
        def get(root):
            node = root
            try:
                for p in path:
                    node = node[p]
                return node
            except (KeyError, IndexError, TypeError):
                return None
        before, after = get(S.original), get(S.data)
        label = ".".join(str(p) for p in path) or "(save)"
        if label == "gold":
            out.append(f"Gold: {int(before or 0):,} → {int(after or 0):,}")
        else:
            out.append(f"{label}: {_fmt(before)} → {_fmt(after)}")
    return out


def changes() -> str:
    return _j(_changes())


def export() -> str:
    bad = [f"{where}: {it.get('name')} — {'; '.join(p)}"
           for where, it in iter_save_items(S.data) for p in [record_problems(it, S.gd)] if p]
    builds = [f"{w}: {p}" for w, p in S.builds.check_save(S.data)] if S.builds else []
    code = codec.verify_roundtrip(S.data)
    lb = S.data.get("leaderboard") if isinstance(S.data.get("leaderboard"), dict) else {}
    return _j({"code": code, "unreadable": bad, "builds": builds, "changes": _changes(),
               "nickname": lb.get("name") or ""})


def reset() -> str:
    S.data = codec.deep_copy(S.original)
    return summary()


def raw_json() -> str:
    return json.dumps(S.data, ensure_ascii=False, indent=1)
