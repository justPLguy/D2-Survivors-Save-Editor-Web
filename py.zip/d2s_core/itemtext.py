"""Readable property lines with ranges, worded like the game's tooltips (D2 description functions).

Input is a property list from itemstats.json ({stats: [{stat, func}], min, max, par}); the
wording comes from the same file (``stats`` pos/str2 strings, ``groups``, ``classes``, ``skills``).
Ranges are shown as ``lo-hi``; fixed values as one number.
"""
from __future__ import annotations

ELEMENTS = {"fire": "Fire", "cold": "Cold", "light": "Lightning", "magic": "Magic", "poison": "Poison"}


def _r(lo, hi):
    lo, hi = (lo, hi) if lo <= hi else (hi, lo)
    return f"{lo}" if lo == hi else f"{lo}-{hi}"


def _num(v):
    return f"{v:g}" if isinstance(v, float) else str(v)


class ItemText:
    def __init__(self, R: dict):
        self.R = R
        self.S = R.get("stats") or {}
        self.G = R.get("groups") or {}
        self.classes = R.get("classes") or []
        self.skills = R.get("skills") or {}

    def skill(self, par):
        if par is None:
            return "?"
        s = self.skills.get(str(par))
        if s:
            return s.get("name") or s.get("skill") or str(par)
        return str(par)

    def _cls(self, idx):
        try:
            return self.classes[int(idx)]
        except (TypeError, ValueError, IndexError):
            return None

    def lines(self, props) -> list[str]:
        out = []
        for p in props or []:
            line = self.prop(p)
            if line:
                out.append(line)
        return out

    def prop(self, p) -> str | None:
        stats = p.get("stats") or []
        if not stats:
            return None
        lo, hi, par = p.get("min", 0), p.get("max", 0), p.get("par")
        names = [s["stat"] for s in stats]
        # damage pairs: Adds x-y <element> damage
        for key, elem in ELEMENTS.items():
            if f"{key}mindam" in names and f"{key}maxdam" in names:
                if key == "poison":
                    length = par or 0
                    if length:
                        a, b = round(lo * length / 256), round(hi * length / 256)
                        return f"+{_r(a, b) if a != b else a} Poison Damage over {length / 25:g} seconds"
                    return f"Adds {_r(lo, hi)} Poison Damage"
                return f"Adds {lo}-{hi} {elem} Damage"
        if "mindamage" in names and "maxdamage" in names:
            return f"Adds {lo}-{hi} Damage"
        if "item_mindamage_percent" in names and "item_maxdamage_percent" in names:
            return f"+{_r(lo, hi)}% Enhanced Weapon Damage"
        # stats sharing a description group (all attributes, all resistances)
        groups = {self.S.get(n, {}).get("group") for n in names}
        if len(stats) > 1 and len(groups) == 1 and None not in groups:
            g = self.G.get(str(groups.pop()))
            if g:
                return self._fmt(g, lo, hi, par, stats[0])
        return self._fmt(self.S.get(names[0]) or {}, lo, hi, par, stats[0])

    def _fmt(self, d, lo, hi, par, st):
        f = d.get("func")
        pos = d.get("pos") or ""
        s2 = d.get("str2") or ""
        v = _r(lo, hi)
        name = st["stat"]
        if "perlevel" in name and par:
            per = par / 8
            return f"+{_num(per)} {pos} per character level".replace("  ", " ").strip()
        if f in (None, 0):
            return None
        tok = {1: ("+", ""), 2: ("", "%"), 3: ("", ""), 4: ("+", "%"), 6: ("+", ""), 7: ("", "%"), 8: ("+", "%"),
               9: ("", ""), 12: ("+", ""), 20: ("-", "%"), 21: ("-", "")}
        if "pierce" in name and f in (19, 20):
            tok[f] = ("-", "%")
        if f in tok or f == 5:
            if f == 5:
                lo, hi = round(lo * 100 / 128), round(hi * 100 / 128)
                sign, pct = "", "%"
            else:
                sign, pct = tok[f]
            if lo < 0 and hi <= 0:
                sign, v = ("" if sign != "-" else "+"), _r(-lo, -hi) if sign == "-" else _r(lo, hi)
            num = f"{sign}{v}{pct}"
            where = 1 if "pierce" in name else d.get("val", 1)
            text = pos if where == 0 else (f"{pos} {num}" if where == 2 else f"{num} {pos}")
            if f in (6, 7, 8, 9) and s2:
                text += " " + s2
            return text.strip()
        if f == 11:
            if par:
                return f"Repairs 1 Durability in {round(100 / par)} Seconds"
            return pos
        if f == 13:
            c = self._cls(st.get("val", par))
            return f"+{v} {c['allSkills']}" if c else f"+{v} to Class Skill Levels"
        if f == 14:
            try:
                c = self._cls(int(par) // 3)
                tab = c["tabs"][int(par) % 3]
                return (tab.replace("%d", v) + " " + c.get("only", "")).strip()
            except (TypeError, ValueError, IndexError, KeyError):
                return f"+{v} to skill tree {par}"
        if f == 15:
            return f"{lo}% Chance to cast level {hi} {self.skill(par)} " + (
                pos.split("%s", 1)[1].strip() if "%s" in pos else "")
        if f == 16:
            return f"Level {v} {self.skill(par)} Aura When Equipped"
        if f == 24 or "Charges" in pos:
            return f"Level {lo} {self.skill(par)} ({hi}/{hi} Charges)"
        if f == 19:
            return pos.replace("%d", v) if "%d" in pos else f"{pos} {v}"
        if f == 20:
            return f"-{v}% {pos}"
        if f == 21:
            return f"-{v} {pos}"
        if f == 23:
            return f"{lo}% {pos} monster #{par}"
        if f == 27:
            return f"+{v} to {self.skill(par)}" + self._only(par)
        if f == 28:
            return f"+{v} to {self.skill(par)}"
        return f"{pos} {v}".strip() or f"{name} {v}"

    def _only(self, par):
        s = self.skills.get(str(par)) or {}
        code = s.get("cls")
        for c in self.classes:
            if c.get("code") == code:
                return " " + c.get("only", "")
        return ""

    # --- single raw stats (set bonuses, wanted-roll labels) -------------------------------
    def stat_line(self, stat, value, param=None) -> str:
        line = self.prop({"stats": [{"stat": stat, "func": 1}], "min": value, "max": value, "par": param})
        return line or f"{stat} {value}"

    def stat_label(self, stat, param=None) -> str:
        """The property's name as the game words it, without the number (for the Wanted rolls column)."""
        d = self.S.get(stat) or {}
        f = d.get("func")
        if f == 16:
            return f"{self.skill(param)} Aura (level)"
        if f == 15:
            return f"Chance to cast {self.skill(param)}"
        if f == 24 or "Charges" in (d.get("pos") or ""):
            return f"{self.skill(param)} charges (level)"
        if f in (27, 28):
            return f"+ to {self.skill(param)}"
        if f == 14:
            line = self.stat_line(stat, 0, param)
            return line.replace("+0 ", "+ ")
        if f == 13:
            return self.stat_line(stat, 0, param).replace("+0 ", "+ ")
        pos = (d.get("pos") or "").replace("%d", "").replace("%s", "").replace("%%", "%").strip()
        if not pos:
            return stat
        pos = " ".join(pos.split())
        if pos.startswith("to "):
            pos = "+ " + pos
        if "perlevel" in stat:
            return f"{pos} per level"
        return pos


# --- the game's tooltip for D2-stat items (bundle SY / tLe / nLe) ------------------------------
_XY = [("mindamage", "maxdamage", "strModMinDamage", "strModMinDamageRange"),
       ("firemindam", "firemaxdam", "strModFireDamage", "strModFireDamageRange"),
       ("lightmindam", "lightmaxdam", "strModLightningDamage", "strModLightningDamageRange"),
       ("magicmindam", "magicmaxdam", "strModMagicDamage", "strModMagicDamageRange"),
       ("coldmindam", "coldmaxdam", "strModColdDamage", "strModColdDamageRange")]
_KJ = ["amazon", "sorceress", "necromancer", "paladin", "barbarian", "druid", "assassin"]
_PROC = {"item_skillonhit", "item_skillonattack", "item_skillongethit", "item_skillonkill",
         "item_skillondeath", "item_skillonlevelup"}
_COOLDOWN = {"staticField", "revive", "corpseExplosion", "ironMaiden", "spiritOfBarbs", "ironGolem"}   # Xi
_REANIMATE = {1: "Returned"}


def _jsn(v):
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v)


def _bY(v):
    return f"+{_jsn(v)}" if v >= 0 else _jsn(v)


def _yY(fmt, *args):
    import re as _re
    it = iter(args)

    def rep(m):
        if m.group(2) == "%":
            return "%"
        a = next(it, "")
        return f"+{_jsn(a)}" if m.group(1) and isinstance(a, (int, float)) and a >= 0 else _jsn(a)
    return _re.sub(r"%(\+?)([ds%])", rep, fmt)


def _jsround(x):
    import math
    return math.floor(x + 0.5)


def _camel(name):
    words = (name or "").replace("'", "").split()
    return (words[0].lower() + "".join(w[:1].upper() + w[1:] for w in words[1:])) if words else ""


class StatTooltip:
    """Lines the game shows for an item's D2 stats (uniques, set items, runewords), in the game's order."""

    def __init__(self, R: dict, overrides: dict | None = None):
        self.R = R
        # the game patches some stat descriptions when it loads itemstats (PIe / FIe with NIe)
        self.S = {k: ({**v, **(overrides or {}).get(k, {})} if k in (overrides or {}) else v)
                  for k, v in (R.get("stats") or {}).items()}
        self.G = R.get("groups") or {}
        self.strings = R.get("strings") or {}
        self.classes = R.get("classes") or []
        self.skills = R.get("skills") or {}

    def _skill_id(self, row):
        return _camel((row or {}).get("skill") or (row or {}).get("name"))

    def _one(self, e, t, n):                                   # tLe
        a = e.get("value", 0)
        o = (t.get("neg") if a < 0 and t.get("neg") else t.get("pos")) or ""
        val = t.get("val")

        def s(x):
            return o if val == 0 else f"{x} {o}" if val == 1 else f"{o} {x}"
        import math
        c = math.floor(a * n / 2 ** (t.get("shift", 3) if t.get("shift") is not None else 3))
        param = e.get("param")
        sk = self.skills.get(str(param)) if param is not None else None
        u = None
        if sk and sk.get("cls"):
            idx = next((i for i, cl in enumerate(self.classes) if cl.get("code") == sk["cls"]), -1)
            u = _KJ[idx] if 0 <= idx < len(_KJ) else None

        def only(cls):
            if not cls:
                return ""
            i = _KJ.index(cls)
            return (self.classes[i].get("only") if i < len(self.classes) else "") or ""
        f = t.get("func")
        if f == 1:
            return s(_bY(a))
        if f == 2:
            return s(f"{_jsn(a)}%")
        if f == 3:
            return s(_jsn(a))
        if f == 4:
            return s(f"{_bY(a)}%")
        if f == 5:
            return s(f"{math.floor(a * 100 / 128)}%")
        if f == 6:
            return f"{s(_bY(c))} {t.get('str2', '')}"
        if f == 7:
            return f"{s(f'{c}%')} {t.get('str2', '')}"
        if f == 8:
            return f"{s(f'{_bY(c)}%')} {t.get('str2', '')}"
        if f == 9:
            return f"{s(str(c))} {t.get('str2', '')}"
        if f == 11:
            return _yY(o, 1, math.floor(100 / a)) if a > 0 else None
        if f == 12:
            return s(_bY(a)) if a > 1 else o
        if f == 13:
            p = -1 if param is None else param
            if 0 <= p < len(_KJ) and p < len(self.classes):
                return f"{_bY(a)} {self.classes[p].get('allSkills', '')}"
            return None
        if f == 14:
            p = -1 if param is None else param
            k = math.floor(p / 3)
            if 0 <= k < len(_KJ) and k < len(self.classes):
                cl = self.classes[k]
                return f"{_yY(cl['tabs'][p % 3], a)} {cl.get('only', '')}"
            return None
        if f == 15:
            if not sk:
                return None
            text = _yY(o, a, e.get("level") if e.get("level") is not None else 1, sk.get("name"))
            if e.get("stat") in _PROC and self._skill_id(sk) in _COOLDOWN:
                text = f"{text} (5s cooldown)"
            return text
        if f == 16:
            return _yY(o, a, sk.get("name")) if sk else None
        if f == 19:
            return _yY(o, a)
        if f == 20:
            return s(f"{_jsn(-a)}%")
        if f == 21:
            return s(_jsn(-a))
        if f == 23:
            r = _REANIMATE.get(-1 if param is None else param)
            return f"{_jsn(a)}% {o} {r}" if r else f"{_jsn(a)}% {o}"
        if f == 24:
            if not sk:
                return None
            now = min(40, a) if self._skill_id(sk) in _COOLDOWN else a
            lvl = e.get("level") if e.get("level") is not None else 1
            return f"{self.strings.get('strchrlvl', 'Level')} {lvl} {sk.get('name')} {_yY(o, now, a)}"
        if f == 27:
            return f"{_bY(a)} {self.strings.get('ItemStast1k', 'to')} {sk.get('name')} {only(u)}".strip() if sk else None
        if f == 28:
            return f"{_bY(a)} {self.strings.get('ItemStast1k', 'to')} {sk.get('name')}" if sk else None
        return None

    def lines(self, stats, n: int = 1) -> list[str]:
        a, keyed = [], {}                                           # nLe: merge repeats without a level
        for r in stats or []:
            k = None if r.get("level") is not None else f"{r.get('stat')}|{'' if r.get('param') is None else r.get('param')}"
            if k is not None and k in keyed:
                i = keyed[k]
                a[i] = {**a[i], "value": a[i]["value"] + r.get("value", 0)}
            else:
                if k is not None:
                    keyed[k] = len(a)
                a.append(dict(r))
        used, out = set(), []

        def c(stat):
            return next((i for i, r in enumerate(a) if r.get("stat") == stat and i not in used), None)

        def prio(ids):
            return max((self.S.get(a[i]["stat"]) or {}).get("priority", 0) or 0 for i in ids)

        def u(text, ids):
            used.update(ids)
            out.append((text, prio(ids)))
        d, f = c("item_maxdamage_percent"), c("item_mindamage_percent")
        if d is not None and f is not None and a[d]["value"] == a[f]["value"]:
            u(f"+{_jsn(a[d]['value'])}% {self.strings.get('strModEnhancedDamage', 'Enhanced Damage')}", [d, f])
        for lo, hi, one, rng in _XY:
            x, y = c(lo), c(hi)
            if x is not None and y is not None:
                vx, vy = a[x]["value"], a[y]["value"]
                text = _yY(self.strings.get(one, ""), vx) if vx == vy else _yY(self.strings.get(rng, ""), vx, vy)
                ids = [x, y]
                if lo == "coldmindam":
                    cl = c("coldlength")
                    if cl is not None:
                        ids.append(cl)
                u(text, ids)
        p, m, h = c("poisonmindam"), c("poisonmaxdam"), c("poisonlength")
        if p is not None and m is not None and h is not None:
            hv = a[h]["value"]
            e1, e2 = (_jsround(a[i]["value"] * hv / 256) for i in (p, m))
            secs = _jsround(hv / 25)
            u(_yY(self.strings.get("strModPoisonDamage", ""), e1, secs) if e1 == e2
              else _yY(self.strings.get("strModPoisonDamageRange", ""), e1, e2, secs), [p, m, h])
        for gid, g in self.G.items():
            ids = [c(st) for st, desc in self.S.items() if desc.get("group") == int(gid)]
            if not ids or any(i is None for i in ids) or any(a[i]["value"] != a[ids[0]]["value"] for i in ids):
                continue
            r = a[ids[0]]["value"]
            txt = (g.get("neg") if r < 0 and g.get("neg") else g.get("pos")) or ""
            u(_yY(txt, r) if g.get("func") == 19 else f"{txt} {_bY(r)}" if g.get("val") == 2 else f"{_bY(r)} {txt}", ids)
        for i, r in enumerate(a):
            if i in used:
                continue
            desc = self.S.get(r.get("stat"))
            text = self._one(r, desc, n) if desc else None
            if text:
                u(text, [i])
            else:
                used.add(i)
        out.sort(key=lambda x: -x[1])
        return [t for t, _p in out]

    def defense(self, item, stats):
        d = item.get("defense")
        if d is None:
            return None
        pct = sum(s.get("value", 0) for s in stats if s.get("stat") == "item_armor_percent")
        flat = sum(s.get("value", 0) for s in stats if s.get("stat") == "armorclass")
        import math
        return math.floor(d * (100 + pct) / 100) + flat
