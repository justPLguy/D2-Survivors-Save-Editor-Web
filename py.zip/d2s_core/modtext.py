"""The game's tooltip line for one saved mod (bundle ``UX`` with its text table ``HX``).

Templates are exported from the game (game_tables.json ``mod_text``) as the game's own arrow
functions, e.g. ``e=>`+${e}% Faster Hit Recovery``` ; the only expressions they use are
``e``, ``e/8``, ``e/2`` and the sign ``e>=0?`+`:```.
"""
from __future__ import annotations

import re

_EXPR = re.compile(r"\$\{([^}]*)\}")


def _js_num(v):
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    if isinstance(v, float):
        return repr(v).rstrip("0").rstrip(".") if "e" not in repr(v) else str(v)
    return str(v)


def words(name: str) -> str:                       # WX: camelCase -> "Camel Case"
    if not name:
        return name
    s = name[0].upper() + name[1:]
    return re.sub(r"([A-Z])", r" \1", s).strip()


class ModText:
    def __init__(self, tables: dict):
        mt = tables.get("mod_text") or {}
        self.templates = mt.get("templates") or {}
        self.tabs = mt.get("tabs") or {}
        self.classes = mt.get("classes") or {}
        self.events = mt.get("proc_events") or {}
        self.cooldown = set(mt.get("cooldown_skills") or [])     # Xi: 5s cooldown, at most 40 charges

    def _eval(self, expr, e):
        expr = expr.strip()
        if expr == "e":
            return _js_num(e)
        if expr == "e/8":
            return _js_num(e / 8)
        if expr == "e/2":
            return _js_num(e / 2)
        if expr.replace(" ", "") == "e>=0?`+`:``":
            return "+" if e >= 0 else ""
        return _js_num(e)

    def line(self, stat: str, value, length=None, short=False) -> str:
        """``short``: floats to at most 2 decimals (the save keeps e.g. 12.916666666666666)."""
        if short and isinstance(value, float) and not value.is_integer():
            value = float(f"{value:.2f}")
        if stat in self.tabs:
            return self.tabs[stat].replace("{v}", _js_num(value))
        if stat in self.classes:
            return self.classes[stat].replace("{v}", _js_num(value))
        if stat.startswith("skill:") or stat.startswith("oskill:"):
            return f"+{_js_num(value)} to {words(stat.split(':', 1)[1])}"
        parts = stat.split(":")
        if parts[0] == "proc" and len(parts) >= 4:
            _p, ev, skill, lvl = parts[:4]
            text = f"{_js_num(value)}% Chance to cast level {lvl} {words(skill)} {self.events.get(ev, '')}".strip()
            return f"{text} (5s cooldown)" if skill in self.cooldown else text
        if parts[0] == "charge" and len(parts) >= 3:
            now = min(40, value) if parts[1] in self.cooldown else value
            return f"Level {parts[2]} {words(parts[1])} ({_js_num(now)}/{_js_num(value)} Charges)"
        if parts[0] == "aura" and len(parts) >= 2:
            return f"Level {_js_num(value)} {words(parts[1])} Aura When Equipped"
        src = self.templates.get(stat)
        if not src:
            return f"{stat}: {_js_num(value)}"
        body = src.split("=>", 1)[1].strip()
        if body.startswith("`") and body.endswith("`"):
            body = body[1:-1]
        return _EXPR.sub(lambda m: self._eval(m.group(1), value), body)

    def item_lines(self, item: dict) -> list[str]:
        return [self.line(m.get("stat", "?"), m.get("value", 0), m.get("length")) for m in item.get("mods") or []]


def _js_round(x):
    import math
    return math.floor(x + 0.5)


class Tooltip(ModText):
    """The game's item tooltip lines for an item's mods (bundle HZ, mods path): sums repeated stats,
    'All Resistances +N' when the four resists are equal, 'Adds x-y <element> Damage' pairs,
    poison over seconds, sorted by the game's priority (qX / eRe)."""

    def __init__(self, tables: dict):
        super().__init__(tables)
        mt = tables.get("mod_text") or {}
        self.priority = mt.get("priority") or {}
        self.implicit_t = mt.get("implicit") or {}
        self.special = mt.get("special") or {}
        self.skip = set(mt.get("skip") or [])
        self.resists = mt.get("resists") or []
        self.pairs = mt.get("damage_pairs") or []

    def _q(self, stat):
        if stat in self.tabs:
            return 151
        if stat in self.classes:
            return 150
        if stat.startswith("proc:"):
            return 160
        if stat.startswith("aura:"):
            return 159
        if stat.startswith("charge:"):
            return 1
        return self.priority.get(stat, 0)

    def _tpl(self, src, value):
        body = src.split("=>", 1)[1].strip()
        if body.startswith("`") and body.endswith("`"):
            body = body[1:-1]
        body = re.sub(r"\$\{(?!e\b)[A-Za-z_$][\w$]*\}", "(Based on Character Level)", body)
        return _EXPR.sub(lambda m: self._eval(m.group(1), value), body)

    def lines(self, item: dict, defense=None) -> list[tuple[str, bool]]:
        """[(text, implicit)] in the game's order (implicit lines first).

        ``defense``: the item's Defense as the game shows it (game 2026.1101.1+: the base's implicit
        Damage Reduction line reads "Defense: N" when the item has a defense)."""
        mods = item.get("mods") or []
        summed: dict[str, dict] = {}
        for m in mods:
            if m.get("implicit") or m.get("stat") in self.skip:
                continue
            st = m.get("stat")
            if st in summed:
                summed[st] = {**summed[st], "value": summed[st]["value"] + m.get("value", 0)}
            else:
                summed[st] = dict(m)
        poison = None
        lengths = [m["length"] for m in mods if m.get("stat") == "poisonMinDamage" and m.get("length")]
        if lengths:
            n = sum(lengths) / len(lengths)
            tot = lambda s: sum(m.get("value", 0) for m in mods if m.get("stat") == s) * n / 256
            poison = {"min": tot("poisonMinDamage"), "max": tot("poisonMaxDamage"), "frames": n}
            summed["poisonMinDamage"] = {"stat": "poisonMinDamage", "value": max(poison["min"], poison["max"])}
        f = [m for m in mods if m.get("implicit")] + [{**m, "value": _js_round(m["value"])} for m in summed.values()]
        f = [m for m in f if m.get("value") != 0]
        res = [m for m in f if not m.get("implicit") and m.get("stat") in self.resists]
        allres = len(res) == len(self.resists) and all(m["value"] == res[0]["value"] for m in res)
        h = [m for m in f if m.get("implicit") or m.get("stat") == self.resists[0] or m.get("stat") not in self.resists] \
            if allres else f

        def g(stat):
            return next((m for m in h if not m.get("implicit") and m.get("stat") == stat), None)
        keep = [m for m in h if m.get("implicit") or not any(m.get("stat") == mx and g(mn) for mn, mx, _n in self.pairs)]
        keep.sort(key=lambda m: -self._q(m.get("stat", "")))
        out = []
        for m in keep:
            st, v, imp = m.get("stat", ""), m.get("value", 0), bool(m.get("implicit"))
            pair = None if imp else next((p for p in self.pairs if p[0] == st), None)
            other = g(pair[1]) if pair else None
            if imp and st == "damageReduction" and defense is not None:
                text = f"Defense: {defense}"
            elif imp and st in self.implicit_t:
                text = self._tpl(self.implicit_t[st], v)
            elif allres and not imp and st == self.resists[0]:
                text = f"All Resistances +{_js_num(v)}"
            elif pair and other:
                text = (f"+{_js_num(v)} {pair[2]} Damage" if v == other["value"]
                        else f"Adds {_js_num(v)}-{_js_num(other['value'])} {pair[2]} Damage")
            elif poison and st == "poisonMinDamage":
                r = int(poison["frames"] // 1)
                k = r / poison["frames"] if poison["frames"] > 0 else 0
                a, b = _js_round(poison["min"] * k), _js_round(poison["max"] * k)
                secs = r // 25
                text = (f"+{a} Poison Damage over {secs} Seconds" if a == b
                        else f"Adds {a}-{b} Poison Damage over {secs} Seconds")
            elif st in self.special:
                text = self.line(st, v)          # per-level stats: worded per level, not for one character level
            else:
                text = self.line(st, v)
            out.append((text, imp))
        return [x for x in out if x[1]] + [x for x in out if not x[1]]

    def defense(self, item: dict):
        """Defense as the tooltip shows it (base defense with Enhanced Defense and flat Defense)."""
        d = item.get("defense")
        if d is None:
            return None
        stats = item.get("stats")
        if isinstance(stats, list):
            pct = sum(s.get("value", 0) for s in stats if s.get("stat") == "item_armor_percent")
            flat = sum(s.get("value", 0) for s in stats if s.get("stat") == "armorclass")
        else:
            pct = sum(m.get("value", 0) for m in item.get("mods") or [] if m.get("stat") == "enhancedDefense" and not m.get("implicit"))
            flat = sum(m.get("value", 0) for m in item.get("mods") or [] if m.get("stat") == "defense" and not m.get("implicit"))
        return int(d * (100 + pct) // 100) + flat
