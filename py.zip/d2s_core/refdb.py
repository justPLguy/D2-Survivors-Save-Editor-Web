"""Read-only access to database/d2r_reference.sqlite.

The connection is opened with ``mode=ro`` so no code path can modify the file,
even by mistake.  One connection is reused instead of one per query.
"""
from __future__ import annotations

import hashlib
import sqlite3
from pathlib import Path


class ReferenceDB:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        uri = self.path.resolve().as_uri() + "?mode=ro"
        self.conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

    def query(self, sql: str, params=()):
        if not sql.lstrip().lower().startswith(("select", "with", "pragma")):
            raise PermissionError("ReferenceDB is read-only")
        return self.conn.execute(sql, params).fetchall()

    def close(self):
        self.conn.close()


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
