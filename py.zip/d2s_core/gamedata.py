"""Game tables used by the item generators (read-only).

Two sources, both produced by the game itself:

* ``data/game_tables.json`` - affix, automagic and base tables exported from the
  game bundle (``moved-*.js``) of the version named in ``game_version``.
* ``itemstats.json`` - the unique/set/runeword/skill tables the game extracts
  from the player's own Diablo II: Resurrected install into
  ``%APPDATA%\\D2 Survivors\\d2``.  That file is preferred; a bundled copy is the
  fallback.

Nothing here writes to disk.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"


def appdata_itemstats_path() -> Path | None:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    p = Path(appdata) / "D2 Survivors" / "d2" / "itemstats.json"
    return p if p.is_file() else None


class GameData:
    def __init__(self, tables_path: str | os.PathLike | None = None,
                 itemstats_path: str | os.PathLike | None = None):
        tables_path = Path(tables_path) if tables_path else DATA / "game_tables.json"
        if itemstats_path is None:
            itemstats_path = appdata_itemstats_path() or (DATA / "itemstats_fallback.json")
        self.tables_path = Path(tables_path)
        self.itemstats_path = Path(itemstats_path)
        t = json.loads(self.tables_path.read_text(encoding="utf-8"))
        self.game_version: str = t.get("game_version", "unknown")
        self.KJ: list[str] = t["KJ"]
        self.Fi: list[str] = t["Fi"]
        self.EX: list[dict] = t["EX"]
        self.RX: dict[str, list] = t["RX"]
        self.bases: dict[str, dict] = {b["name"]: b for b in t["HY"]}
        self.NY: dict[str, dict] = t["NY"]
        self.XLe = t["XLe"]
        self.ZLe = t["ZLe"]
        self.sBe: dict[str, int] = t["sBe"]
        self.oBe: dict[str, int] = t["oBe"]
        self.cBe = set(t["cBe"])
        self.wLe = t["wLe"]
        self.eX = t["eX"]
        self.ZX = set(t["ZX"])
        self.zRe = set(t["zRe"])
        self.Yi = set(t["Yi"])
        self.L = set(t["L_keys"])
        self._J = set(t["_J_keys"])
        self.ea = set(t["ea_keys"])
        self.uniques_list: list[dict] = t["BX"]   # {name, base, lvl, ethereal?}
        self.sets_list: list[dict] = t["wY"]      # {name, base, set, lvl, rarity...}
        self.HX = set(t.get("HX_keys", []))
        self.XX = t.get("XX", ["normal", "magic", "rare", "set", "runeword", "unique"])
        self.limits = t.get("limits", {"affix": 14, "auto": 4, "implicit": 1, "stat_abs_max": 1000,
                                       "max_stats": 48, "grid_coord_max": 10, "poison_length_max": 511})
        self.runeword_list: list[dict] = t.get("EY", [])      # {name, runes, types, lvl}
        self.runeword_defs = {r["name"]: r for r in self.runeword_list}
        self.runes: list[dict] = t.get("TY", [])                # {code, name, level}
        self.rw_quality = t.get("rw_quality", {"Lze": 0.75, "Rze": [25, 57]})
        self.tier2 = set(t.get("tier2", []))                    # elite base codes
        self.tier1 = set(t.get("tier1", []))                    # exceptional base codes
        self.unique_defs = {u["name"]: u for u in self.uniques_list}
        self.set_defs = {s["name"]: s for s in self.sets_list}
        self.R = normalize_item_data(json.loads(self.itemstats_path.read_text(encoding="utf-8")))
        self._fy_cache: dict[tuple[str, str], bool] = {}

    # --- item-type equivalence (the game's FY) ---------------------------------
    def FY(self, e: str, t: str) -> bool:
        key = (e, t)
        hit = self._fy_cache.get(key)
        if hit is not None:
            return hit
        if e == t:
            res = t in self.NY
        else:
            res = any(self.FY(q, t) for q in (self.NY.get(e) or {}).get("equiv", []))
        self._fy_cache[key] = res
        return res

    def installed_game_version(self) -> str | None:
        """Version of the D2 Survivors app that extracted %APPDATA%\\D2 Survivors\\d2 (desktop-stamp.json)."""
        stamp = self.itemstats_path.parent / "desktop-stamp.json"
        try:
            return json.loads(stamp.read_text(encoding="utf-8")).get("app")
        except (OSError, ValueError):
            return None

    @property
    def skills(self) -> dict:
        return self.R.get("skills", {})


# --- game 2026.1102.1: Diablo II (1.14d) and Resurrected files give a few rows differently ---------------
# The game's xW / CW / wW / RUe / HUe: on install the rows are brought to the 1.14d form, and the legit
# check also accepts an item rolled from the other form (UUe).
VERSION_ROWS = {
    "setItems": {
        "Bul-Kathos' Sacred Charge": {"on": "1.14d", "before": "item_maxdamage_percent",
                                       "prop": {"stats": [{"stat": "item_knockback", "func": 1}], "min": 1, "max": 1}},
        "Naj's Circlet": {"on": "D2R", "before": "strength",
                          "prop": {"stats": [{"stat": "item_lightradius", "func": 1}], "min": 5, "max": 5}},
    },
    "runewords": {"Famine": {"stat": "coldlength", "par": 100}},
}


def _has(prop, stat):
    return any(s.get("stat") == stat for s in prop.get("stats", []))


def row_version(kind, name, row):
    """CW: '1.14d', 'D2R' or None (not a row that differs)."""
    r = VERSION_ROWS[kind].get(name)
    if not r:
        return None
    props = row.get("props") or []
    if "prop" in r:
        if any(_has(p, r["prop"]["stats"][0]["stat"]) for p in props):
            return r["on"]
        if any(_has(p, r["before"]) for p in props):
            return "D2R" if r["on"] == "1.14d" else "1.14d"
        return None
    hit = next((p for p in props if _has(p, r["stat"])), None)
    if not hit:
        return None
    if hit.get("par") == r["par"]:
        return "1.14d"
    return "D2R" if "par" not in hit else None


def other_version(kind, name, row):
    """wW: the same row in the other file's form (None when the row is not one of them)."""
    v = row_version(kind, name, row)
    if not v:
        return None
    r = VERSION_ROWS[kind][name]
    props = row.get("props") or []
    if "prop" in r:
        stat = r["prop"]["stats"][0]["stat"]
        if v == r["on"]:
            return {**row, "props": [p for p in props if not _has(p, stat)]}
        i = next(k for k, p in enumerate(props) if _has(p, r["before"]))
        add = {**r["prop"], "stats": [dict(x) for x in r["prop"]["stats"]]}
        return {**row, "props": props[:i] + [add] + props[i:]}
    out = []
    for p in props:
        if not _has(p, r["stat"]):
            out.append(p)
        elif v == "D2R":
            out.append({**p, "par": r["par"]})
        else:
            out.append({k: val for k, val in p.items() if k != "par"})
    return {**row, "props": out}


def normalize_item_data(R):
    """HUe: Resurrected rows become their 1.14d form."""
    if not isinstance(R, dict):
        return R
    for kind in VERSION_ROWS:
        rows = R.get(kind)
        if not isinstance(rows, dict):
            continue
        for name in VERSION_ROWS[kind]:
            row = rows.get(name)
            if row and row_version(kind, name, row) == "D2R":
                rows[name] = other_version(kind, name, row)
    return R


@lru_cache(maxsize=4)
def load_game_data(tables_path: str | None = None, itemstats_path: str | None = None) -> GameData:
    return GameData(tables_path, itemstats_path)
