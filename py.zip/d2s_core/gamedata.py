"""Game tables used by the item generators (read-only).

Two sources, both produced by the game itself:

* ``data/game_tables.json`` - affix, automagic and base tables exported from the
  game bundle (``moved-*.js``) of the version named in ``game_version``.
* ``itemstats.json`` - the unique/set/runeword/skill tables the game extracts
  from the player's own Diablo II: Resurrected install into
  ``%APPDATA%\\D2 Survivors\\d2``.  That file is preferred; a bundled copy is the
  fallback.

Nothing here writes to disk.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"


def appdata_itemstats_path() -> Path | None:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    p = Path(appdata) / "D2 Survivors" / "d2" / "itemstats.json"
    return p if p.is_file() else None


class GameData:
    def __init__(self, tables_path: str | os.PathLike | None = None,
                 itemstats_path: str | os.PathLike | None = None):
        tables_path = Path(tables_path) if tables_path else DATA / "game_tables.json"
        if itemstats_path is None:
            itemstats_path = appdata_itemstats_path() or (DATA / "itemstats_fallback.json")
        self.tables_path = Path(tables_path)
        self.itemstats_path = Path(itemstats_path)
        t = json.loads(self.tables_path.read_text(encoding="utf-8"))
        self.game_version: str = t.get("game_version", "unknown")
        self.KJ: list[str] = t["KJ"]
        self.Fi: list[str] = t["Fi"]
        self.EX: list[dict] = t["EX"]
        self.RX: dict[str, list] = t["RX"]
        self.bases: dict[str, dict] = {b["name"]: b for b in t["HY"]}
        self.NY: dict[str, dict] = t["NY"]
        self.XLe = t["XLe"]
        self.ZLe = t["ZLe"]
        self.sBe: dict[str, int] = t["sBe"]
        self.oBe: dict[str, int] = t["oBe"]
        self.cBe = set(t["cBe"])
        self.wLe = t["wLe"]
        self.eX = t["eX"]
        self.ZX = set(t["ZX"])
        self.zRe = set(t["zRe"])
        self.Yi = set(t["Yi"])
        self.L = set(t["L_keys"])
        self._J = set(t["_J_keys"])
        self.ea = set(t["ea_keys"])
        self.uniques_list: list[dict] = t["BX"]   # {name, base, lvl, ethereal?}
        self.sets_list: list[dict] = t["wY"]      # {name, base, set, lvl, rarity...}
        self.HX = set(t.get("HX_keys", []))
        self.XX = t.get("XX", ["normal", "magic", "rare", "set", "runeword", "unique"])
        self.limits = t.get("limits", {"affix": 14, "auto": 4, "implicit": 1, "stat_abs_max": 1000,
                                       "max_stats": 48, "grid_coord_max": 10, "poison_length_max": 511})
        self.runeword_list: list[dict] = t.get("EY", [])      # {name, runes, types, lvl}
        self.runeword_defs = {r["name"]: r for r in self.runeword_list}
        self.runes: list[dict] = t.get("TY", [])                # {code, name, level}
        self.rw_quality = t.get("rw_quality", {"Lze": 0.75, "Rze": [25, 57]})
        self.tier2 = set(t.get("tier2", []))                    # elite base codes
        self.tier1 = set(t.get("tier1", []))                    # exceptional base codes
        self.unique_defs = {u["name"]: u for u in self.uniques_list}
        self.set_defs = {s["name"]: s for s in self.sets_list}
        self.R = json.loads(self.itemstats_path.read_text(encoding="utf-8"))
        self._fy_cache: dict[tuple[str, str], bool] = {}

    # --- item-type equivalence (the game's FY) ---------------------------------
    def FY(self, e: str, t: str) -> bool:
        key = (e, t)
        hit = self._fy_cache.get(key)
        if hit is not None:
            return hit
        if e == t:
            res = t in self.NY
        else:
            res = any(self.FY(q, t) for q in (self.NY.get(e) or {}).get("equiv", []))
        self._fy_cache[key] = res
        return res

    def installed_game_version(self) -> str | None:
        """Version of the D2 Survivors app that extracted %APPDATA%\\D2 Survivors\\d2 (desktop-stamp.json)."""
        stamp = self.itemstats_path.parent / "desktop-stamp.json"
        try:
            return json.loads(stamp.read_text(encoding="utf-8")).get("app")
        except (OSError, ValueError):
            return None

    @property
    def skills(self) -> dict:
        return self.R.get("skills", {})


@lru_cache(maxsize=4)
def load_game_data(tables_path: str | None = None, itemstats_path: str | None = None) -> GameData:
    return GameData(tables_path, itemstats_path)
