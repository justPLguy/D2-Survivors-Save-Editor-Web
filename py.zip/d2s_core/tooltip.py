"""The item tooltip as the game draws it: D2-stat items (uniques, sets, runewords) through the game's
SY, other items through its mods path (HZ).  Both match the game's own code line for line
(tests/test_tooltip.py)."""
from __future__ import annotations

from .itemtext import StatTooltip
from .modtext import Tooltip


class GameTooltip:
    def __init__(self, tables: dict, R: dict, factory=None):
        self.mods = Tooltip(tables)
        self.R = R
        self.stats = StatTooltip(R, tables.get("stat_desc_overrides"))
        self.req = None
        if factory is not None:          # game 2026.1102.1: "Required Level: N" (Mq)
            from .requirements import Requirements
            self.req = Requirements(factory)

    # --- base damage (game: eKe for mods, tKe for D2 stats) and base defense ---------------------------------
    PER_LEVEL_HALF = {"attackRatingPerLevel", "attackRatingPercentPerLevel", "undeadAttackRatingPerLevel",
                      "demonAttackRatingPerLevel"}

    @classmethod
    def _per_level(cls_, stat, value, clvl):                         # iJ / yJ
        import math
        return math.floor(value * clvl / 2) if stat in cls_.PER_LEVEL_HALF else math.floor(value * clvl / 8)

    def _base(self, item):
        b = self.req.gd.bases.get(item.get("base")) if self.req is not None else None
        return b

    def _eth(self, item):                                             # yq
        gd = self.req.gd
        return (item.get("rarity") == "unique" and item.get("name") in gd.zRe) or \
            (item.get("rarity") == "runeword" and bool(item.get("ethereal")))

    def _hands(self, item, base):                                     # bq
        import math
        eth = self._eth(item)
        f = (lambda r: [math.floor(3 * x / 2) for x in r]) if eth else (lambda r: list(r))
        one, two = base.get("oneHand"), base.get("twoHand")
        return (f(one) if one else None), (f(two) if two else None)

    def damage_lines(self, item, clvl=1):
        """'One-Hand Damage: a to b' / 'Two-Hand Damage: a to b' exactly as the game draws them."""
        import math
        base = self._base(item)
        if not base or item.get("base") == "Wirt's Leg":
            return []
        one, two = self._hands(item, base)
        if not one and not two:
            return []
        out = []
        stats = item.get("stats")
        if isinstance(stats, list):                                   # tKe
            s = lambda st: sum(x.get("value", 0) for x in stats if x.get("stat") == st)
            d, f, p = s("item_maxdamage_percent"), s("mindamage"), s("maxdamage")
            m = self._per_level("maxDamagePerLevel", s("item_maxdamage_perlevel"), clvl)
            h = self._per_level("maxDamagePercentPerLevel", s("item_maxdamage_percent_perlevel"), clvl)
            changed = bool(d or f or p or m or h)
            for key, r in (("One-Hand Damage:", one), ("Two-Hand Damage:", two)):
                if r:
                    lo = math.floor(r[0] * (100 + d) / 100) + f
                    hi = max(lo + 1, math.floor(r[1] * (100 + d + h) / 100) + p + m)
                    out.append((f"{key} {lo} to {hi}", "damage" if changed else "implicit"))
            return out
        mods = item.get("mods") or []                                 # eKe
        r_ = lambda st: sum(x.get("value", 0) for x in mods if x.get("stat") == st)
        i, a, o = r_("enhancedDamage"), r_("minDamage"), r_("maxDamage")
        sv = self._per_level("maxDamagePerLevel", r_("maxDamagePerLevel"), clvl)
        cv = self._per_level("maxDamagePercentPerLevel", r_("maxDamagePercentPerLevel"), clvl)
        changed = bool(i or a or o or sv or cv)

        def u(rng):
            n = math.floor(rng[0] * (100 + i) / 100) + a
            hi = math.floor(rng[1] * (100 + i + cv) / 100) + o + sv
            return round(n), round(max(n + 1, hi) if changed else hi)
        for key, r in (("One-Hand Damage:", one), ("Two-Hand Damage:", two)):
            if r:
                lo, hi = u(r)
                out.append((f"{key} {lo} to {hi}", "damage" if changed else "implicit"))
        return out

    def base_defense_line(self, item):
        """Editor's own line (not the game's): the base defense the item rolled, and the base's range."""
        rng = ((self.R.get("bases") or {}).get(item.get("base")) or {}).get("defense")
        d = item.get("defense")
        if not rng or d is None:
            return []
        eth = " (ethereal: x1.5)" if item.get("ethereal") else ""
        return [(f"Base Defense: {d} (base {rng[0]}-{rng[1]}{eth})", "base")]

    def _req(self, item, cls):
        t = self.req.line(item, cls) if self.req is not None else None
        return [(t, "implicit")] if t else []

    def lines(self, item: dict, clvl: int = 1, cls: str | None = None) -> list[tuple[str, str]]:
        """[(text, kind)] with kind 'defense', 'implicit', 'stat' or 'bonus'."""
        out = []
        stats = item.get("stats")
        if isinstance(stats, list):
            d = self.stats.defense(item, stats)
            if d is not None:
                out.append((f"Defense: {d}", "defense"))
                out += self.base_defense_line(item)
            if self.req is not None:
                out += self.damage_lines(item, clvl)
            out += self._req(item, cls)
            out += [(t, "stat") for t in self.stats.lines(stats, clvl)]
            for n, grp in enumerate(item.get("bonus") or [], 2):
                out += [(f"{t}   ({n} items)", "bonus") for t in self.stats.lines(grp, clvl)]
            return out
        d = self.defense_pq(item)
        stat_lines = []
        if self.req is not None:
            out += self.damage_lines(item, clvl)
        for t, imp in self.mods.lines(item, d):
            if not imp:
                stat_lines.append((t, "stat"))
            else:
                out.append((t, "defense" if t.startswith("Defense: ") else "implicit"))
                if t.startswith("Defense: "):
                    out += self.base_defense_line(item)
        return out + self._req(item, cls) + stat_lines

    def defense_pq(self, item: dict):
        """pQ: base defense (the item's, else the middle of the base's range) with every Enhanced Defense mod,
        plus armorclass from D2 stats - the number the game shows (2026.1101.1)."""
        t = item.get("defense")
        if t is None:
            rng = ((self.R.get("bases") or {}).get(item.get("base")) or {}).get("defense")
            t = (rng[0] + rng[1]) // 2 if rng else None
        n = sum(s.get("value", 0) for s in item.get("stats") or [] if s.get("stat") == "armorclass")
        if t is None:
            return None
        r = sum(m.get("value", 0) for m in item.get("mods") or [] if m.get("stat") == "enhancedDefense")
        return int(t * (100 + r) // 100) + n
