"""The item tooltip as the game draws it: D2-stat items (uniques, sets, runewords) through the game's
SY, other items through its mods path (HZ).  Both match the game's own code line for line
(tests/test_tooltip.py)."""
from __future__ import annotations

from .itemtext import StatTooltip
from .modtext import Tooltip


class GameTooltip:
    def __init__(self, tables: dict, R: dict):
        self.mods = Tooltip(tables)
        self.R = R
        self.stats = StatTooltip(R, tables.get("stat_desc_overrides"))

    def lines(self, item: dict, clvl: int = 1) -> list[tuple[str, str]]:
        """[(text, kind)] with kind 'defense', 'implicit', 'stat' or 'bonus'."""
        out = []
        stats = item.get("stats")
        if isinstance(stats, list):
            d = self.stats.defense(item, stats)
            if d is not None:
                out.append((f"Defense: {d}", "defense"))
            out += [(t, "stat") for t in self.stats.lines(stats, clvl)]
            for n, grp in enumerate(item.get("bonus") or [], 2):
                out += [(f"{t}   ({n} items)", "bonus") for t in self.stats.lines(grp, clvl)]
            return out
        d = self.defense_pq(item)
        for t, imp in self.mods.lines(item, d):
            kind = "stat" if not imp else ("defense" if t.startswith("Defense: ") else "implicit")
            out.append((t, kind))
        return out

    def defense_pq(self, item: dict):
        """pQ: base defense (the item's, else the middle of the base's range) with every Enhanced Defense mod,
        plus armorclass from D2 stats - the number the game shows (2026.1101.1)."""
        t = item.get("defense")
        if t is None:
            rng = ((self.R.get("bases") or {}).get(item.get("base")) or {}).get("defense")
            t = (rng[0] + rng[1]) // 2 if rng else None
        n = sum(s.get("value", 0) for s in item.get("stats") or [] if s.get("stat") == "armorclass")
        if t is None:
            return None
        r = sum(m.get("value", 0) for m in item.get("mods") or [] if m.get("stat") == "enhancedDefense")
        return int(t * (100 + r) // 100) + n
