"""The item tooltip as the game draws it: D2-stat items (uniques, sets, runewords) through the game's
SY, other items through its mods path (HZ).  Both match the game's own code line for line
(tests/test_tooltip.py)."""
from __future__ import annotations

from .itemtext import StatTooltip
from .modtext import Tooltip


class GameTooltip:
    def __init__(self, tables: dict, R: dict, factory=None):
        self.mods = Tooltip(tables)
        self.R = R
        self.stats = StatTooltip(R, tables.get("stat_desc_overrides"))
        self.req = None
        if factory is not None:          # game 2026.1102.1: "Required Level: N" (Mq)
            from .requirements import Requirements
            self.req = Requirements(factory)

    def _req(self, item, cls):
        t = self.req.line(item, cls) if self.req is not None else None
        return [(t, "implicit")] if t else []

    def lines(self, item: dict, clvl: int = 1, cls: str | None = None) -> list[tuple[str, str]]:
        """[(text, kind)] with kind 'defense', 'implicit', 'stat' or 'bonus'."""
        out = []
        stats = item.get("stats")
        if isinstance(stats, list):
            d = self.stats.defense(item, stats)
            if d is not None:
                out.append((f"Defense: {d}", "defense"))
            out += self._req(item, cls)
            out += [(t, "stat") for t in self.stats.lines(stats, clvl)]
            for n, grp in enumerate(item.get("bonus") or [], 2):
                out += [(f"{t}   ({n} items)", "bonus") for t in self.stats.lines(grp, clvl)]
            return out
        d = self.defense_pq(item)
        stat_lines = []
        for t, imp in self.mods.lines(item, d):
            if not imp:
                stat_lines.append((t, "stat"))
            else:
                out.append((t, "defense" if t.startswith("Defense: ") else "implicit"))
        return out + self._req(item, cls) + stat_lines

    def defense_pq(self, item: dict):
        """pQ: base defense (the item's, else the middle of the base's range) with every Enhanced Defense mod,
        plus armorclass from D2 stats - the number the game shows (2026.1101.1)."""
        t = item.get("defense")
        if t is None:
            rng = ((self.R.get("bases") or {}).get(item.get("base")) or {}).get("defense")
            t = (rng[0] + rng[1]) // 2 if rng else None
        n = sum(s.get("value", 0) for s in item.get("stats") or [] if s.get("stat") == "armorclass")
        if t is None:
            return None
        r = sum(m.get("value", 0) for m in item.get("mods") or [] if m.get("stat") == "enhancedDefense")
        return int(t * (100 + r) // 100) + n
