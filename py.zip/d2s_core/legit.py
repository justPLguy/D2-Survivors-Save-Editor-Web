"""The game's per-item legit check (bundle ``WHe`` with ``_Re``, ``lLe``, ``DY``, ``OY``, ``kY``, ``mRe``).

``check(item)`` returns None when the game shows the item as legit, else ``{"fault", "why"}`` worded
like the game.  Items with a ``roll`` are regenerated (mRe); items without one (most real drops)
get the range rules: affixes of the base within 125% of their most (magic/rare), every stat inside
its property row (unique/set/runeword), defense within the base's.
"""
from __future__ import annotations

import math
import re

from .records import record_problems

SKILL_RE = re.compile(r"^(classskills|skilltab)\d+$")
AFFIX_MAX = {"normal": 0, "magic": 2, "rare": 6}       # gRe


def _fault(kind, why):
    return {"fault": kind, "why": why}


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


class LegitCheck:
    def __init__(self, factory, tables: dict):
        self.f = factory
        self.gd = factory.gd
        self.most = tables.get("stat_most") or {}
        self._hre: dict[str, dict] = {}

    # --- magic / rare / normal (_Re) ---------------------------------------------------
    def hre(self, base):
        hit = self._hre.get(base["name"])
        if hit:
            return hit
        t = {"affix": {}, "auto": {}, "implicit": {}}

        def put(m, stat, v):
            m[stat] = max(m.get(stat, -math.inf), v)
        aff = self.f.affixes
        for r in self.gd.EX:
            if aff.gX(r, base, r.get("cls")):
                put(t["affix"], r["stat"], r["max"])
                d2 = r.get("d2") or {}
                for st in d2.get("alike") or []:
                    put(t["affix"], st, r["max"])
                if d2.get("also"):
                    put(t["affix"], d2["also"]["stat"], d2["also"]["max"])
        for row in self.gd.RX.get(base["itype"], []):
            for e in aff.roll_auto(None, row, "max"):
                put(t["auto"], e["stat"], e["value"])
        if base.get("implicit"):
            put(t["implicit"], base["implicit"]["stat"], base["implicit"]["value"])
        self._hre[base["name"]] = t
        return t

    def _re(self, item):
        rar = item.get("rarity")
        if rar in ("unique", "set", "runeword") or item.get("type") == "quest":
            return None
        base = self.gd.bases.get(item.get("base"))
        if not base:
            return _fault("stat", "a base the game has none of")
        n = self.hre(base)
        mods = item.get("mods") or []
        if rar == "normal" and any(not m.get("implicit") and not m.get("auto") for m in mods):
            return _fault("affixes", "an affix on a white item")
        for m in mods:
            kind = "implicit" if m.get("implicit") else "auto" if m.get("auto") else "affix"
            top = n[kind].get(m.get("stat"))
            if top is None:
                word = {"implicit": "own", "auto": "automagic", "affix": "affix"}[kind]
                return _fault("stat", f"{m.get('stat')}: no {word} stat of {base['name']}'s")
            if not m.get("implicit") and m.get("value", 0) > math.ceil(top * 1.25):
                return _fault("range", f"{m.get('stat')} {m.get('value')} past its most on {base['name']}, {top}")
        if len(self.f.affixes.recognise(item, base)) > AFFIX_MAX.get(rar, 0):
            return _fault("affixes", f"more affixes than a {rar} item holds")
        if sum(1 for m in mods if not m.get("implicit") and not m.get("auto") and SKILL_RE.match(str(m.get("stat")))) > 1:
            return _fault("rule", "two +skills prefixes, where an item takes one")
        return None

    # --- ranges (lLe) ------------------------------------------------------------------
    @staticmethod
    def _rng(p):                                                   # cLe
        par = p.get("par") or 0
        return min(p["min"], p["max"], par), max(p["min"], p["max"], par, 1)

    def _dy(self, stats, props):                                   # DY
        slots = [{"stat": s["stat"], "range": self._rng(p), "used": False} for p in props for s in p["stats"]]
        if len(stats) > len(slots):
            return "more stats than its row"
        for st in stats:
            stat, v = st.get("stat"), st.get("value")
            hit = next((e for e in slots if not e["used"] and e["stat"] == stat
                        and e["range"][0] <= v <= e["range"][1]), None)
            if hit is None:
                return f"{stat} {v} outside its row"
            hit["used"] = True
        return None

    def _oy(self, mods):                                           # OY
        for m in mods:
            top = self.most.get(m.get("stat"))
            if top is None:
                return _fault("stat", f"{m.get('stat')}: a stat no item has")
            if m.get("value", 0) > math.ceil(top * 1.25):
                return _fault("range", f"{m.get('stat')} {m.get('value')} past its most, {top}")
        return None

    def _ky(self, item):                                           # kY
        d = item.get("defense")
        bd = (self.gd.R.get("bases", {}).get(item.get("base")) or {}).get("defense") if d is not None else None
        if not bd:
            return None
        top = math.floor((bd[1] + 1) * 3 / 2) if item.get("ethereal") is True else bd[1] + 1
        return _fault("range", f"{item.get('base')}: defense {d} past its base's") if d > top else None

    def _no_stats(self, item, word):
        mods = item.get("mods") or []
        if len(mods) > 1 or any(not m.get("implicit") for m in mods):
            return _fault("unique", f"a {word} without its stats")
        return self._oy(mods) or self._ky(item)

    def lle(self, item):
        R = self.gd.R
        rar, name, stats = item.get("rarity"), item.get("name"), item.get("stats")
        has = isinstance(stats, list)
        if rar == "unique":
            if not has:
                if name == "Wirt's Leg" and not item.get("mods"):
                    return None
                return self._no_stats(item, "unique")
            row = (R.get("uniques") or {}).get(name)
            if not row:
                return _fault("unique", f"{name}: a unique the game has none of")
            why = self._dy(stats, row["props"])
            if why:
                return _fault("unique", f"{name}: {why}")
        elif rar == "set":
            if not has:
                return self._no_stats(item, "set item")
            row = (R.get("setItems") or {}).get(name)
            if not row:
                return _fault("unique", f"{name}: a set item the game has none of")
            why = self._dy(stats, row["props"])
            if why:
                return _fault("unique", f"{name}: {why}")
            bonus = item.get("bonus") or []
            if len(bonus) > len(row.get("bonus") or []):
                return _fault("unique", f"{name}: more green bonuses than its row")
            for n, grp in enumerate(bonus):
                why = self._dy(grp, row["bonus"][n])
                if why:
                    return _fault("unique", f"{name}: a green bonus's {why}")
        elif rar == "runeword":
            rw = self.gd.runeword_defs.get(name)
            if not rw:
                return _fault("unique", f"{name}: a runeword the game has none of")
            if not has:
                return _fault("unique", "a runeword without its stats")
            row = (R.get("runewords") or {}).get(name)
            if not row:
                return _fault("unique", f"{name}: a runeword the tables have none of")
            t = item.get("type")
            slot = "weapon" if t == "weapon" else "shield" if t == "shield" else "helm"
            props = list(row["props"]) + [p for r in rw["runes"] for p in (R.get("runes", {}).get(r) or {}).get(slot, [])]
            why = self._dy(stats, props)
            if why:
                return _fault("unique", f"{name}: {why}")
        else:
            if item.get("ethereal") is True:
                return _fault("stat", "ethereal, on an item that is no runeword")
            if has:
                return _fault("stat", "D2 stats on an item that is no unique or set item")
            mods = item.get("mods") or []
            f = self._oy(mods)
            if f:
                return f
            if sum(1 for m in mods if not m.get("implicit") and not m.get("auto") and SKILL_RE.match(str(m.get("stat")))) > 1:
                return _fault("stat", "two +skills prefixes, where an item takes one")
        return self._ky(item)

    # --- the whole check (WHe) ----------------------------------------------------------
    def check(self, item):
        if item.get("type") == "quest":
            return None
        f = self._re(item)
        if f:
            return f
        rar = item.get("rarity")
        if rar in ("unique", "runeword") and item.get("stats") is None:     # JS: !e.stats ([] is truthy)
            return None
        if not self._compact_ok(item):
            return _fault("rule", "an item the record cannot keep")
        f = self.lle(item)
        if f:
            if f["fault"] == "unique" and rar in ("set", "runeword"):
                f = {**f, "fault": rar}
            return f
        if record_problems(item, self.gd):
            return _fault("rule", "an item the game no longer reads")
        if self.f.verify(item) is False:
            return _fault("seed", "not what its roll makes")
        return None

    @staticmethod
    def _compact_ok(item):                                         # R1, the parts that matter
        def s(v, n=None):
            return isinstance(v, str) and len(v) > 0 and (n is None or len(v) <= n)
        if not (s(item.get("id"), 40) and s(item.get("base")) and s(item.get("type"), 16) and s(item.get("name"))
                and _num(item.get("level")) and item.get("rarity") in ("normal", "magic", "rare", "set", "unique", "runeword")):
            return False
        if isinstance(item.get("stats"), list):
            return all(isinstance(x, dict) and s(x.get("stat")) and _num(x.get("value")) for x in item["stats"])
        mods = item.get("mods")
        return isinstance(mods, list) and all(isinstance(m, dict) and s(m.get("stat")) and _num(m.get("value")) for m in mods)
