"""Item requirements, ported from game 2026.1102.1 (bundle ``eq``, ``tq``, ``YK``, ``QK``, ``kGe``, ``$K``, ``$Ue``).

The game shows "Required Level: N" on every item whose requirement is above 1 (the tooltip's ``Mq``).
It does not stop heroes from wearing items (its ``rq`` always allows it); the line is information only.
"""
from __future__ import annotations

import math

CLASS_CODE = {"amazon": "ama", "sorceress": "sor", "necromancer": "nec", "paladin": "pal",
              "barbarian": "bar", "druid": "dru", "assassin": "ass"}
WIRTS_LEG = "Wirt's Leg"


def _jsmax(a, b):
    if a is None or b is None or (isinstance(a, float) and math.isnan(a)) or (isinstance(b, float) and math.isnan(b)):
        return float("nan")
    return max(a, b)


class Requirements:
    def __init__(self, factory):
        self.f = factory
        self.gd = factory.gd

    # --- affixes the item carries (YK) -------------------------------------------------------
    def affix_req(self, aff, base):                                   # QK
        d2 = aff.get("d2")
        if d2:
            return d2.get("req")
        if not aff.get("req"):
            return 0
        FY = self.gd.FY
        n = next((k for k, r in enumerate(aff.get("rows") or [])
                  if any(FY(base["itype"], x) for x in r.get("on", [])) and not any(FY(base["itype"], x) for x in r.get("not", []))), -1)
        reqs = aff["req"]
        i = max(0, n)
        return reqs[i] if i < len(reqs) else 0

    def affixes(self, item):                                          # YK
        base = self.gd.bases.get(item.get("base"))
        if not base:
            return []
        mods = item.get("mods") or []

        def n(m, spec):
            return (not m.get("implicit") and not m.get("auto") and m.get("stat") == spec["stat"]
                    and spec["min"] <= m.get("value", 0) <= spec["max"])

        def alike_ok(t, m):
            return all(any(not x.get("implicit") and not x.get("auto") and x.get("stat") == st and x.get("value") == m.get("value")
                           for x in mods) for st in ((t.get("d2") or {}).get("alike") or []))

        def ok(t, m):
            d2 = t.get("d2") or {}
            return (n(m, t) and m.get("length") == d2.get("length")
                    and (not d2.get("also") or any(n(x, d2["also"]) for x in mods)) and alike_ok(t, m))

        def fits(t):
            return self.f.affixes.gX(t, base, t.get("cls"))
        out = []
        rar = item.get("rarity")
        name = item.get("name") or ""
        if rar == "magic":
            hit = [t for t in self.gd.EX
                   if (name.startswith(f"{t['name']} ") if t["kind"] == "prefix" else name.endswith(f" {t['name']}"))
                   and fits(t) and any(ok(t, m) for m in mods)]
            hit.sort(key=lambda t: self.affix_req(t, base))
            seen = set()
            for t in hit:
                k = (t["kind"], t["name"])
                if k not in seen:
                    seen.add(k)
                    out.append(t)
        elif rar == "rare":
            r = [m for m in mods if not m.get("implicit") and not m.get("auto")]

            def span(t, idx):
                rest = r[idx + 1:]
                d2 = t.get("d2") or {}
                alike = d2.get("alike") or []
                a = all(k < len(rest) and rest[k].get("stat") == st and rest[k].get("value") == r[idx].get("value")
                        for k, st in enumerate(alike))
                o = len(alike)
                s = not d2.get("also") or (o < len(rest) and n(rest[o], d2["also"]))
                return o + (1 if d2.get("also") else 0) if a and s else -1
            e = 0
            while e < len(r):
                cands = [t for t in self.gd.EX
                         if n(r[e], t) and r[e].get("length") == (t.get("d2") or {}).get("length") and fits(t) and span(t, e) >= 0]
                if cands:
                    cands.sort(key=lambda t: (-span(t, e), self.affix_req(t, base)))
                    s = cands[0]
                    out.append(s)
                    e += span(s, e)
                e += 1
        return [t for t in out if t["kind"] == "prefix"] + [t for t in out if t["kind"] == "suffix"]

    def auto_req(self, item, base):                                   # kGe / $K
        auto = [m for m in item.get("mods") or [] if m.get("auto")]
        if not auto:
            return 0
        reqs = []
        for row in self.gd.RX.get(base["itype"], []):
            lo = self.f.affixes.roll_auto(None, row, "min")
            hi = self.f.affixes.roll_auto(None, row, "max")
            if len(lo) == len(auto) and all(m.get("stat") == lo[k]["stat"] and lo[k]["value"] <= m.get("value", 0) <= hi[k]["value"]
                                            for k, m in enumerate(auto)):
                reqs.append(row.get("req"))
        return min(reqs) if reqs else 0

    def _skill_req(self, s, cls):                                     # $Ue
        p = s.get("param")
        sk = None if p is None else (self.gd.R.get("skills") or {}).get(str(p))
        if not sk:
            return 0
        if s.get("stat") == "item_singleskill":
            return sk.get("reqlevel", 0)
        if s.get("stat") == "item_nonclassskill":
            return sk.get("reqlevel", 0) + (0 if cls and sk.get("cls") == CLASS_CODE.get(cls) else 6)
        return 0

    def level(self, item, cls=None):                                  # eq
        base = self.gd.bases.get(item.get("base"))
        if not base or item.get("base") == WIRTS_LEG:
            return 0
        R = self.gd.R
        r = ((R.get("bases") or {}).get(item.get("base")) or {}).get("level") or 0
        rar = item.get("rarity")
        if rar in ("magic", "rare"):
            for t in self.affixes(item):
                r = _jsmax(r, self.affix_req(t, base))
            r = _jsmax(r, self.auto_req(item, base))
        elif rar == "unique":
            r = max(r, ((R.get("uniques") or {}).get(item.get("name")) or {}).get("level") or 0)
        elif rar == "set":
            r = max(r, ((R.get("setItems") or {}).get(item.get("name")) or {}).get("level") or 0)
        elif rar == "runeword":
            rw = self.gd.runeword_defs.get(item.get("name"))
            if rw:
                lv = {x["name"]: x["level"] for x in self.gd.runes}
                r = max(r, max(lv.get(x, 0) for x in rw["runes"]))
        for s in item.get("stats") or []:
            r = _jsmax(r, self._skill_req(s, cls))
        return r

    def line(self, item, cls=None):
        """Mq without a hero: the tooltip line, or None at level 1 and below."""
        n = self.level(item, cls)
        if isinstance(n, float) and math.isnan(n):
            return "Required Level: NaN"
        return f"Required Level: {n}" if n > 1 else None
