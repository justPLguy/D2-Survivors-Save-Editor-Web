"""Unique, set and runeword item generator, ported 1:1 from the game bundle.

Game functions: IQ (unique), BQ/ZJ/VQ (set), XQ/XJ (runeword), tY (property
roll), DZ/JIe (stats, mods, defense), qIe (proc/charge level from item level).
Property tables come from the game's own ``itemstats.json``.
"""
from __future__ import annotations

import math

from ..jsmath import JSRandom, jj
from .display import Display


class UniqueRules:
    def __init__(self, gd):
        self.gd = gd
        self.display = Display(gd)

    def qIe(self, par, mx, ilvl):
        if mx > 0:
            return mx
        r = self.gd.skills.get(str(par)) if par is not None else None
        if not r:
            return 1
        req, maxlvl = r["reqlevel"], r["maxlvl"]
        i = math.floor((ilvl - req) / 4) + 1
        a = math.floor((ilvl - req) * maxlvl / (99 - req)) if req != 99 else (math.inf if ilvl > req else 0)
        return max(1, min(maxlvl, max(i, a)))

    def roll_props(self, rng: JSRandom, props, ilvl):
        """The game's tY: one draw per property, then one record per stat of it."""
        out = []
        for p in props:
            e = jj(rng, p["min"], p["max"])
            par = p.get("par")
            for s in p["stats"]:
                func = s.get("func")

                def c(value, param=None, level=None):
                    rec = {"stat": s["stat"], "value": value}
                    if param is not None:
                        rec["param"] = param
                    if level is not None:
                        rec["level"] = level
                    out.append(rec)

                if func == 15:
                    c(p["min"])
                elif func == 16:
                    c(p["max"])
                elif func == 17:
                    c(par or e)
                elif func in (10, 22):
                    c(e, par)
                elif func == 21:
                    c(e, s.get("val"))
                elif func in (11, 19):
                    c(p["min"], par, self.qIe(par, p["max"], ilvl))
                elif func == 12:
                    c(1 if par is None else par, jj(rng, p["min"], p["max"]))
                else:
                    c(e)
        return out

    def defense(self, rng, base_name, stats):  # JIe
        d = (self.gd.R.get("bases", {}).get(base_name) or {}).get("defense")
        if not d:
            return None
        if any(s["stat"] == "item_armor_percent" for s in stats):
            return d[1] + 1
        return jj(rng, d[0], d[1])

    def _dz(self, rng, base, stats, eth=False):
        d = self.defense(rng, base["name"], stats)
        out = {"stats": stats, "mods": self.display.base_mods(base, eth) + self.display.stats_to_mods(stats)}
        if d is not None:
            out["defense"] = d
        return out

    @staticmethod
    def _level(level):
        return min(1_000_000, max(0, level))

    def unique(self, seed: int, name: str, level: int, ilvl: int):
        rng = JSRandom(seed)
        u = self.gd.unique_defs[name]
        base = self.gd.bases[u["base"]]
        row = self.gd.R.get("uniques", {}).get(name)
        eth = name in self.gd.zRe
        body = self._dz(rng, base, self.roll_props(rng, row["props"], ilvl), eth) if row is not None \
            else {"mods": self.display.base_mods(base, eth)}
        return {"base": base["name"], "type": base["type"], "rarity": "unique", "name": name,
                "level": self._level(level), **body}

    def set_item(self, seed: int, name: str, level: int, ilvl: int):
        rng = JSRandom(seed)
        s = self.gd.set_defs[name]
        base = self.gd.bases[s["base"]]
        row = self.gd.R.get("setItems", {}).get(name)
        if row is None:
            body = {"mods": self.display.base_mods(base, False)}
        else:
            stats = self.roll_props(rng, row["props"], ilvl)
            bonus = [self.roll_props(rng, b, ilvl) for b in row["bonus"]] if row.get("bonus") else None
            # BQ builds its result literal as {id: _$(), ..., ...VQ()}: the id's Math.random()
            # is drawn before VQ rolls the base defense (unlike IQ, which rolls defense first).
            rng.random()
            body = self._dz(rng, base, stats)
            if bonus:
                body["bonus"] = bonus
        return {"base": base["name"], "type": base["type"], "rarity": "set", "name": name,
                "level": self._level(level), **body}
