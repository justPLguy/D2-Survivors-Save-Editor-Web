"""Runewords, ported 1:1 from the game bundle.

XQ (the item), XJ (runeword + rune properties in rune order), KQ (rune slot),
GQ (base type allowed), YQ (bases a runeword can drop on), VIe (sockets by item
level), Ize (can be ethereal).  Wiki: runewords drop finished; level = highest rune.
"""
from __future__ import annotations

import math

from ..jsmath import JSRandom
from .unique import UniqueRules


class RunewordRules:
    def __init__(self, gd, uniques: UniqueRules, affixes=None):
        self.gd = gd
        self.u = uniques
        self.affixes = affixes      # game 2026.1102.1: a class base keeps its automagic (TK) on a runeword

    # --- base rules ------------------------------------------------------------------
    def allowed_type(self, rw, base) -> bool:  # GQ
        FY = self.gd.FY
        return (any(FY(base["itype"], t) for t in rw["types"])
                and not any(FY(base["itype"], t) for t in rw.get("excluded") or []))

    @staticmethod
    def slot(base) -> str:  # KQ
        return "weapon" if base["type"] == "weapon" else "shield" if base["type"] == "shield" else "helm"

    def _wj(self, name):
        return self.gd.R.get("bases", {}).get(name) or {}

    def sockets(self, base_name, ilvl) -> int:  # VIe
        s = self._wj(base_name).get("sockets")
        if not s:
            return 0
        return s[0 if ilvl <= 25 else 1 if ilvl <= 40 else 2]

    def can_be_ethereal(self, base_name) -> bool:  # Ize
        return not self._wj(base_name).get("noDurability")

    def tier(self, code) -> int:  # YY
        return 2 if code in self.gd.tier2 else (1 if code in self.gd.tier1 else 0)

    def _qq(self, base, dmg="default"):  # qQ
        n = self._wj(base["name"])
        if dmg == "default":
            dmg = base.get("twoHand") if base.get("twoHand") is not None else base.get("oneHand")
        r, i = dmg if dmg else (0, 0)
        if base["type"] == "weapon":
            v = (r + i) / 2
        else:
            d = n.get("defense")
            v = d[1] if d else 1
        return v / (1 + (n.get("str") or 0) / 100)

    def _jq(self, base):  # JQ
        if base["type"] == "weapon":
            out = []
            for key, dmg in ((f"{base['itype']} 1", base.get("oneHand")), (f"{base['itype']} 2", base.get("twoHand"))):
                if dmg:
                    out.append((key, self._qq(base, dmg)))
            return out
        return [(base["itype"], self._qq(base))]

    def _zze(self, rw):
        lo, hi = self.gd.rw_quality["Rze"]
        return self.gd.rw_quality["Lze"] * min(1, max(0, (rw["lvl"] - lo) / (hi - lo)))

    def drop_bases(self, rw_name, ilvl, treasure_level=99, cls=None) -> list[dict]:
        """YQ: the bases this runeword can drop on at this item level (best-tier, near-best quality)."""
        rw = self.gd.runeword_defs[rw_name]
        i = [b for b in self.gd.bases.values()
             if b["qlvl"] <= treasure_level and self.allowed_type(rw, b) and self.sockets(b["name"], ilvl) >= len(rw["runes"])]
        a = [b for b in i if not b.get("cls") or b.get("cls") == cls] if cls else i
        o = a if a else i
        if not o:
            return []
        s = max(self.tier(b["code"]) for b in o)
        c = s - 1 if sum(1 for b in o if self.tier(b["code"]) == s) < 3 else s
        lst = [b for b in o if self.tier(b["code"]) >= c]
        if not lst:
            return lst
        best = {}
        for b in lst:
            for k, v in self._jq(b):
                best[k] = max(best.get(k, 0), v)

        def d(b):
            return max(v / best[k] for k, v in self._jq(b))
        f = min(3, len(lst))
        p = sorted(lst, key=lambda b: -d(b))
        m = min(self._zze(rw), d(p[f - 1]))
        return [b for b in lst if d(b) >= m]

    def all_bases(self, rw_name) -> list[dict]:
        rw = self.gd.runeword_defs[rw_name]
        return [b for b in self.gd.bases.values() if self.allowed_type(rw, b)]

    # --- the item (XQ) ------------------------------------------------------------------
    def runeword(self, seed: int, name: str, base_name: str, ethereal: bool, level: int, ilvl: int):
        rng = JSRandom(seed)
        rw = self.gd.runeword_defs[name]
        base = self.gd.bases[base_name]
        R = self.gd.R
        row = (R.get("runewords") or {}).get(name)
        body = None
        if row and row.get("props") and R.get("runes"):
            slot = self.slot(base)
            props = list(row["props"]) + [p for rune in rw["runes"] for p in (R["runes"].get(rune) or {}).get(slot, [])]
            stats = self.u.roll_props(rng, props, ilvl)
            body = self.u._dz(rng, base, stats, ethereal)
            if self.affixes is not None:     # GJ: o.mods = [...o.mods, ...TK(base, ilvl, false)]
                body["mods"] = body["mods"] + self.affixes.automagic(rng, base, ilvl, False)
        else:
            body = {"mods": self.u.display.base_mods(base, ethereal)}
        if ethereal and body.get("defense") is not None:
            body["defense"] = math.floor(body["defense"] * 3 / 2)
        item = {"base": base["name"], "type": base["type"], "rarity": "runeword", "name": name,
                "level": min(1_000_000, max(0, level))}
        if ethereal:
            item["ethereal"] = True
        item.update(body)
        return item

    def rune_level(self, name) -> int:  # Gze
        rw = self.gd.runeword_defs[name]
        lv = {r["name"]: r["level"] for r in self.gd.runes}
        return max(lv[r] for r in rw["runes"])
