"""Native item stats -> display mods, ported 1:1 from the game's ``lY`` table.

The game stores unique/set/runeword items with both ``stats`` (native D2 stat
records, the source of truth) and ``mods`` (what the tooltip and the hero use).
``mods`` are always computed from ``stats`` by this table, so the editor never
writes a mod by hand.
"""
from __future__ import annotations

import math
import re

from ..jsmath import js_round, num


def _z(stat, value):
    return {"stat": stat, "value": num(value)}


def camel_skill(name: str) -> str:
    """The game's ``cY``: 'Lightning Bolt' -> 'lightningBolt'."""
    t = re.sub(r"[^A-Za-z ]", "", name)
    t = re.sub(r" (\w)", lambda m: m.group(1).upper(), t)
    return t[:1].lower() + t[1:]


class Display:
    def __init__(self, gd):
        self.gd = gd
        self.skills = gd.skills
        self.KJ = gd.KJ
        self.Fi = gd.Fi

    # class / skill-tab names --------------------------------------------------
    def _kj(self, i):
        return self.KJ[i] if isinstance(i, int) and 0 <= i < len(self.KJ) else None

    def Ri(self, cls):
        return f"classskills{self.Fi.index(cls) if cls in self.Fi else -1}"

    def Ii(self, cls, page):
        idx = self.Fi.index(cls) if cls in self.Fi else -1
        return f"skilltab{idx * 3 + page - 1}"

    # skill names ---------------------------------------------------------------
    def _skill(self, param):
        if param is None:
            return None
        return self.skills.get(str(param))

    def sY(self, n):
        if not n:
            return None
        t = camel_skill(n["skill"])
        return t if t in self.gd.L else None

    def hY(self, n):
        if not n:
            return None
        t = camel_skill(n["skill"])
        return t if (t in self.gd._J or (t == "telekinesis" and n.get("cls") == "sor")) else None

    def gY(self, n):
        t = self.hY(n)
        s = self.sY(n)
        if s is not None:
            return s
        return t if (t and t in self.gd.ea) else None

    def YIe(self, n):
        t = n and camel_skill(n["skill"])
        return t if (t and t in self.gd.Yi) else None

    def mY(self, e, kind="skill"):
        n = self._skill(e.get("param"))
        r = self.sY(n)
        if r is None:
            r = self.hY(n)
        return [_z(f"{kind}:{r}", e["value"])] if r else []

    def pY(self, event, e):
        n = self.gY(self._skill(e.get("param")))
        lvl = e.get("level")
        return [_z(f"proc:{event}:{n}:{1 if lvl is None else lvl}", e["value"])] if n and e["value"] > 0 else []

    # the table -----------------------------------------------------------------
    def convert_one(self, e, ctx):
        s = e["stat"]
        v = e.get("value")
        simple = SIMPLE.get(s)
        if simple is not None:
            name, factor = simple
            return [_z(name, v if factor == 1 else v * factor if factor != "div60" else v / 60)]
        if s == "item_elemskill":
            t = {1: "fireSkills", 2: "lightningSkills", 4: "coldSkills"}.get(e.get("param") or 0)
            return [_z(t, v)] if t else []
        if s == "item_addclassskills":
            p = e.get("param")
            cls = self._kj(-1 if p is None else p)
            return [_z(self.Ri(cls), v)] if cls else []
        if s == "item_addskill_tab":
            p = -1 if e.get("param") is None else e["param"]
            cls = self._kj(math.floor(p / 3))
            return [_z(self.Ii(cls, (e.get("param") or 0) % 3 + 1), v)] if cls else []
        if s == "item_singleskill":
            return self.mY(e)
        if s == "item_nonclassskill":
            return self.mY(e, "oskill")
        if s in CONST_ONE:
            return [_z(CONST_ONE[s], 1)]
        if s == "item_normaldamage":
            return [_z("minDamage", v), _z("maxDamage", v)]
        if s == "poisonmindam":
            n = next((x.get("value") for x in ctx if x.get("stat") == "poisonlength"), None)
            out = _z("poisonMinDamage", v)
            if n and n > 0:
                out["length"] = n
            return [out]
        if s == "armorclass":
            return [_z("damageReduction", v / 60)]
        if s == "armorclass_vs_missile":
            return [_z("missileReduction", v / 60)]
        if s == "armorclass_vs_hth":
            return [_z("meleeReduction", v / 60)]
        if s == "item_howl":
            return [_z("fleeTarget", v * 100 / 128)]
        if s == "item_damagetargetac":
            return [_z("defensePerHit", -v)] if v < 0 else []
        if s in ("item_undead_tohit", "item_demon_tohit"):
            return [_z("undeadAttackRating" if s == "item_undead_tohit" else "demonAttackRating", v * 0.25)]
        if s in FCR_FACTORS:
            return [_z("fcr", v * FCR_FACTORS[s])]
        if s in PROC_EVENTS:
            return self.pY(PROC_EVENTS[s], e)
        if s == "item_charged_skill":
            t = self.gY(self._skill(e.get("param")))
            lvl = e.get("level")
            return [_z(f"charge:{t}:{1 if lvl is None else lvl}", v)] if t and v > 0 else []
        if s == "item_aura":
            t = self.YIe(self._skill(e.get("param")))
            return [_z(f"aura:{t}", v)] if t and v > 0 else []
        return []

    def stats_to_mods(self, stats):
        """The game's ``_Y``: flatMap of the table over a stat list (the list is the context)."""
        out = []
        for e in stats:
            out.extend(self.convert_one(e, stats))
        return out

    def base_mods(self, base, ethereal=False):
        """The game's ``kZ``: the base's own (implicit) modifier."""
        imp = base.get("implicit")
        if not imp:
            return []
        if not ethereal or imp.get("stat") != "attackDamage":
            return [dict(imp)]
        dmg = base.get("twoHand") or base.get("oneHand")
        lo, hi = (math.floor(3 * x / 2) for x in dmg)
        out = dict(imp)
        out["value"] = js_round(6 * math.sqrt((lo + hi) / 2))
        return [out]


FCR_FACTORS = {"item_maxmana_percent": 0.25, "manarecoverybonus": 0.25,
               "item_damagetomana": 0.25, "item_manaafterkill": 1}
PROC_EVENTS = {"item_skillonhit": "hit", "item_skillonattack": "attack", "item_skillongethit": "struck",
               "item_skillonkill": "kill", "item_skillondeath": "death", "item_skillonlevelup": "levelup"}
CONST_ONE = {"item_cannotbefrozen": "cannotBeFrozen", "item_halffreezeduration": "halfFreeze",
             "item_knockback": "knockback", "item_ignoretargetac": "ignoreDefense",
             "item_preventheal": "preventHeal", "item_restinpeace": "restInPeace"}
SIMPLE = {k: (v, 1) for k, v in {
    "item_allskills": "allSkills", "strength": "strength", "dexterity": "dexterity", "energy": "energy",
    "vitality": "vitality", "maxhp": "life", "item_hp_perlevel": "lifePerLevel", "hpregen": "replenishLife",
    # game 2026.1101.1: stamina stats became real mods (they regenerate life now)
    "maxstamina": "stamina", "item_stamina_perlevel": "staminaPerLevel", "staminarecoverybonus": "healStamina",
    "item_regenstamina_perlevel": "healStaminaPerLevel",
    "item_fastercastrate": "fcr", "item_fasterattackrate": "attackSpeed", "item_fastermovevelocity": "frw",
    "item_magicbonus": "magicFind", "item_goldbonus": "goldFind", "item_armor_percent": "enhancedDefense",
    "damageresist": "damageReduction", "normal_damage_reduction": "damageReduced",
    "fireresist": "fireResist", "coldresist": "coldResist", "lightresist": "lightningResist",
    "poisonresist": "poisonResist", "maxfireresist": "maxFireResist", "maxcoldresist": "maxColdResist",
    "maxlightresist": "maxLightningResist", "maxpoisonresist": "maxPoisonResist",
    "item_attackertakesdamage": "thorns", "item_attackertakeslightdamage": "lightningThorns",
    "lifedrainmindam": "lifeLeech", "item_crushingblow": "crushingBlow", "item_deadlystrike": "deadlyStrike",
    "item_deadlystrike_perlevel": "deadlyPerLevel", "item_openwounds": "openWounds", "item_pierce": "pierce",
    "item_healafterkill": "lifeAfterKill", "item_healafterdemonkill": "lifeAfterDemonKill",
    "item_poisonlengthresist": "poisonLength", "item_undeaddamage_percent": "undeadDamage",
    "item_demondamage_percent": "demonDamage", "tohit": "attackRatingPoints",
    "item_tohit_percent": "attackRating", "passive_fire_mastery": "fireMastery",
    "passive_cold_mastery": "coldMastery", "passive_ltng_mastery": "lightningMastery",
    "passive_pois_mastery": "poisonMastery", "passive_fire_pierce": "firePierce",
    "passive_cold_pierce": "coldPierce", "passive_ltng_pierce": "lightningPierce",
    "passive_pois_pierce": "poisonPierce", "item_maxdamage_percent": "enhancedDamage",
    "mindamage": "minDamage", "maxdamage": "maxDamage", "firemindam": "fireMinDamage",
    "firemaxdam": "fireMaxDamage", "lightmindam": "lightningMinDamage", "lightmaxdam": "lightningMaxDamage",
    "coldmindam": "coldMinDamage", "coldmaxdam": "coldMaxDamage", "magicmindam": "magicMinDamage",
    "magicmaxdam": "magicMaxDamage", "poisonmaxdam": "poisonMaxDamage", "item_lightradius": "lightRadius",
    "toblock": "block", "item_fasterblockrate": "fasterBlock", "item_fastergethitrate": "fhr",
    "item_reducedprices": "reducedPrices", "item_absorbfire_percent": "absorbFirePercent",
    "item_absorbcold_percent": "absorbColdPercent", "item_absorblight_percent": "absorbLightningPercent",
    "item_absorbfire": "absorbFire", "item_absorbcold": "absorbCold", "item_absorbmagic": "absorbMagic",
    "item_absorblight": "absorbLightning", "item_absorb_fire_perlevel": "absorbFirePerLevel",
    "item_absorb_cold_perlevel": "absorbColdPerLevel", "item_absorb_ltng_perlevel": "absorbLightningPerLevel",
    "item_vitality_perlevel": "vitalityPerLevel", "item_maxdamage_perlevel": "maxDamagePerLevel",
    "item_fire_damagemax_perlevel": "fireMaxDamagePerLevel", "item_cold_damagemax_perlevel": "coldMaxDamagePerLevel",
    "item_ltng_damagemax_perlevel": "lightningMaxDamagePerLevel", "item_armor_perlevel": "defensePerLevel",
    "item_find_magic_perlevel": "magicFindPerLevel", "item_damage_demon_perlevel": "demonDamagePerLevel",
    "item_resist_ltng_perlevel": "lightningResistPerLevel", "item_thorns_perlevel": "thornsPerLevel",
    "item_tohit_perlevel": "attackRatingPerLevel", "item_tohitpercent_perlevel": "attackRatingPercentPerLevel",
    "item_strength_perlevel": "strengthPerLevel", "item_dexterity_perlevel": "dexterityPerLevel",
    "item_maxdamage_percent_perlevel": "maxDamagePercentPerLevel", "item_damage_undead_perlevel": "undeadDamagePerLevel",
    "item_find_gold_perlevel": "goldFindPerLevel", "item_tohit_undead_perlevel": "undeadAttackRatingPerLevel",
    "item_tohit_demon_perlevel": "demonAttackRatingPerLevel", "item_maxhp_percent": "lifePercent",
    "item_addexperience": "addExperience", "magic_damage_reduction": "magicReduced",
    "item_stupidity": "blindTarget", "item_freeze": "freezeTarget", "item_slow": "slowTarget",
    "item_fractionaltargetac": "targetDefense", "item_magicarrow": "magicArrows",
    "item_explosivearrow": "explosiveArrows", "maxmana": "mana", "item_mana_perlevel": "manaPerLevel",
    "manadrainmindam": "manaLeech",
}.items()}

# Every stat the game's table knows; a test checks this list against the bundle export.
KNOWN_STATS = (set(SIMPLE) | set(CONST_ONE) | set(FCR_FACTORS) | set(PROC_EVENTS) | {
    "item_elemskill", "item_addclassskills", "item_addskill_tab", "item_singleskill", "item_nonclassskill",
    "item_normaldamage", "poisonmindam", "armorclass", "armorclass_vs_missile", "armorclass_vs_hth",
    "item_howl", "item_damagetargetac", "item_undead_tohit", "item_demon_tohit", "item_charged_skill", "item_aura"})
