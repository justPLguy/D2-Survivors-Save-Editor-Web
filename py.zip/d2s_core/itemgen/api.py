"""High-level item creation for the editor.

Every item is made from a seed exactly as the game makes it, then given the
record shape the game writes (``id`` first, ``roll`` after the generated
fields).  ``verify`` regenerates an item from its ``roll`` and compares it the
way the game's legitimacy check does (JSON text of ``stats``/``bonus`` and
``defense`` for unique/set; ``name`` and mods for magic/rare).
"""
from __future__ import annotations

import json
import secrets
import string
import time
from typing import Callable, Iterable

from ..gamedata import GameData, load_game_data
from .magic import AffixRules
from .runeword import RunewordRules
from .unique import UniqueRules

ID_ALPHABET = string.ascii_lowercase + string.digits


def new_item_id(existing: Iterable[str] = ()) -> str:
    """16-character id in the shape seen in real saves; never reuses an id already in the save."""
    taken = set(existing)
    while True:
        value = "".join(secrets.choice(ID_ALPHABET) for _ in range(16))
        if value not in taken:
            return value


def _j(x):
    return json.dumps(x, separators=(",", ":"), ensure_ascii=False)


class ItemFactory:
    def __init__(self, gd: GameData | None = None):
        self.gd = gd or load_game_data()
        self.affixes = AffixRules(self.gd)
        self.uniques = UniqueRules(self.gd)
        self.runewords = RunewordRules(self.gd, self.uniques)

    # --- raw generation (no id/roll) ---------------------------------------------
    def roll(self, kind: str, seed: int, name: str, level: int, ilvl: int, cls: str | None = None,
             base: str | None = None, ethereal: bool = False) -> dict:
        """kind: 'magic' | 'rare' | 'normal' (name = base name), 'unique' | 'set' (name = item name),
        'runeword' (name = runeword, base = base name, ethereal)."""
        seed &= 0xFFFFFFFF
        if kind == "runeword":
            return self.runewords.runeword(seed, name, base, ethereal, level, ilvl)
        if kind == "unique":
            return self.uniques.unique(seed, name, level, ilvl)
        if kind == "set":
            return self.uniques.set_item(seed, name, level, ilvl)
        return self.affixes.generate(seed, name, kind, level, ilvl, cls)

    def make(self, *args, **kwargs) -> dict:
        """Not part of the DEMO: item creation is in the full version (free on Discord)."""
        raise RuntimeError("Item creation is in the full version of D2 Survivors Save Editor (free on Discord).")

    # --- legitimacy of an existing item (the game's mRe) -------------------------------
    def verify(self, item: dict):
        """True: matches its roll.  False: does not.  None: cannot be checked (no roll, unknown item)."""
        roll = item.get("roll")
        if not isinstance(roll, list) or len(roll) < 3 or roll[0] != 1:
            return None
        seed, ilvl = roll[1], roll[2]
        cls = roll[3] if len(roll) > 3 else None
        rarity = item.get("rarity")
        if item.get("type") == "quest" or item.get("base") == "Wirt's Leg":
            return None                       # fixed items: the game never rolls them
        if item.get("base") not in self.gd.bases:
            return False
        if rarity in ("unique", "set"):
            defs = self.gd.unique_defs if rarity == "unique" else self.gd.set_defs
            d = defs.get(item.get("name"))
            if not d or d["base"] != item.get("base"):
                return None if rarity == "unique" else False
            g = self.roll(rarity, seed, item["name"], item.get("level", 0), ilvl)
            if "stats" not in g:
                return None
            return (_j(g["stats"]) == _j(item.get("stats")) and
                    (rarity != "set" or _j(g.get("bonus")) == _j(item.get("bonus"))) and
                    g.get("defense") == item.get("defense"))
        if rarity == "runeword":
            rw = self.gd.runeword_defs.get(item.get("name"))
            base = self.gd.bases.get(item.get("base"))
            if not rw or not self.runewords.allowed_type(rw, base):
                return False
            g = self.roll("runeword", seed, item["name"], item.get("level", 0), ilvl,
                          base=item["base"], ethereal=bool(item.get("ethereal")))
            if "stats" not in g:
                return None
            return _j(g["stats"]) == _j(item.get("stats")) and g.get("defense") == item.get("defense")
        g = self.roll(rarity, seed, item["base"], item.get("level", 0), ilvl, cls)

        def key(ms):
            return [[m.get("stat"), m.get("value"), bool(m.get("implicit")), bool(m.get("auto")), m.get("length")]
                    for m in ms]
        return g["name"] == item.get("name") and g["rarity"] == rarity and _j(key(g["mods"])) == _j(key(item.get("mods", [])))

    # --- seed search ------------------------------------------------------------------------
    def search(self, *args, **kwargs):
        """Not part of the DEMO: seed search is in the full version (free on Discord)."""
        raise RuntimeError("Item search is in the full version of D2 Survivors Save Editor (free on Discord).")
