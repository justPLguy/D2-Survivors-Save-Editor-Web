"""Not part of the DEMO: the multi-core seed search is in the full version (free on Discord)."""


def affix_count(factory, item) -> int:
    try:
        return len(factory.affixes.recognise(item, factory.gd.bases[item["base"]]))
    except Exception:
        return 0


def judge(*args, **kwargs):
    raise RuntimeError("Item search is in the full version of D2 Survivors Save Editor (free on Discord).")


def workers() -> int:
    return 1


def parallel_search(*args, **kwargs):
    raise RuntimeError("Item search is in the full version of D2 Survivors Save Editor (free on Discord).")
