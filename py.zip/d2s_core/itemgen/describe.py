"""What an item actually carries, where each value comes from, and the range the game allows for it.

Rows are built from the same tables the game rolls from:
* unique / set / runeword: the item's property list (itemstats.json), replayed in roll order;
* magic / rare / normal: the affixes the game recognises on the item (cZ), automagic rows (RX), the base's own mod.

Each row: {key, where, index, stat, value, lo, hi, rolls, source, linked}
``where`` is 'stats', 'bonus:<n>' or 'mods'; ``rolls`` False means the game never varies it.
"""
from __future__ import annotations

ROLLING_FUNCS = {None, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 13, 14, 18, 20, 21, 22, 23, 24}


def _prop_rows(props, records, where, label):
    rows = []
    idx = 0
    for p in props:
        lo, hi = min(p["min"], p["max"]), max(p["min"], p["max"])
        par = p.get("par")
        for s in p["stats"]:
            if idx >= len(records):
                return rows, False
            rec = records[idx]
            func = s.get("func")
            if func == 15:
                r = (p["min"], p["min"], False)
            elif func == 16:
                r = (p["max"], p["max"], False)
            elif func == 17:
                r = (par, par, False) if par else (lo, hi, lo != hi)
            elif func in (11, 19):
                r = (p["min"], p["min"], False)
            elif func == 12:
                v = 1 if par is None else par
                r = (v, v, False)
            else:
                r = (lo, hi, lo != hi)
            rows.append({"where": where, "index": idx, "stat": rec.get("stat"), "value": rec.get("value"),
                         "lo": r[0], "hi": r[1], "rolls": r[2], "source": label, "linked": None,
                         "param": rec.get("param"), "level": rec.get("level")})
            idx += 1
    return rows, idx == len(records)


class Describer:
    def __init__(self, factory):
        self.f = factory
        self.gd = factory.gd

    def props_for(self, item):
        """(stats props, [bonus props...]) the game rolls this item from, or (None, None)."""
        R, name, rarity = self.gd.R, item.get("name"), item.get("rarity")
        if rarity == "unique":
            row = (R.get("uniques") or {}).get(name)
            return (row["props"], []) if row else (None, None)
        if rarity == "set":
            row = (R.get("setItems") or {}).get(name)
            return (row["props"], row.get("bonus") or []) if row else (None, None)
        if rarity == "runeword":
            row = (R.get("runewords") or {}).get(name)
            rw = self.gd.runeword_defs.get(name)
            base = self.gd.bases.get(item.get("base"))
            if not row or not rw or not base:
                return None, None
            slot = self.f.runewords.slot(base)
            return (list(row["props"]) + [p for r in rw["runes"] for p in (R.get("runes", {}).get(r) or {}).get(slot, [])], [])
        return None, None

    def rows(self, item) -> tuple[list[dict], list[str]]:
        notes = []
        rarity = item.get("rarity")
        if rarity in ("unique", "set", "runeword") and isinstance(item.get("stats"), list):
            props, bonus = self.props_for(item)
            if props is None:
                notes.append("The game's tables have no entry for this item: ranges unknown.")
                return [self._plain("stats", i, s, "unknown") for i, s in enumerate(item["stats"])], notes
            label = {"unique": "unique property", "set": "set property", "runeword": "runeword / rune"}[rarity]
            rows, ok = _prop_rows(props, item["stats"], "stats", label)
            if not ok:
                notes.append("Stats do not line up with the game's property list (edited or older item).")
            for n, (bp, rec) in enumerate(zip(bonus, item.get("bonus") or []), 1):
                brows, _ = _prop_rows(bp, rec, f"bonus:{n}", f"set bonus ({n + 1} items)")
                rows += brows
            return self._keyed(rows), notes
        return self._keyed(self._mod_rows(item, notes)), notes

    # --- magic / rare / normal --------------------------------------------------------
    def _mod_rows(self, item, notes):
        mods = item.get("mods") or []
        base = self.gd.bases.get(item.get("base"))
        rows = []
        assigned = {}
        if base:
            for aff in self.f.affixes.recognise(item, base):
                d2 = aff.get("d2") or {}
                main = next((i for i, m in enumerate(mods) if i not in assigned and not m.get("implicit")
                             and not m.get("auto") and m.get("stat") == aff["stat"]
                             and aff["min"] <= m.get("value", 0) <= aff["max"]), None)
                if main is None:
                    continue
                src = f"{aff['kind']} “{aff['name']}”"
                assigned[main] = (aff["min"], aff["max"], aff["min"] != aff["max"], src, None)
                for st in d2.get("alike") or []:
                    j = next((i for i, m in enumerate(mods) if i not in assigned and m.get("stat") == st
                              and m.get("value") == mods[main].get("value")), None)
                    if j is not None:
                        assigned[j] = (aff["min"], aff["max"], False, src, main)
                also = d2.get("also")
                if also:
                    j = next((i for i, m in enumerate(mods) if i not in assigned and not m.get("implicit")
                              and not m.get("auto") and m.get("stat") == also["stat"]), None)
                    if j is not None:
                        fixed = bool(d2.get("length"))
                        lo = also["max"] if fixed else also["min"]
                        assigned[j] = (lo, also["max"], (not fixed) and also["min"] != also["max"], src, None)
            auto = [i for i, m in enumerate(mods) if m.get("auto")]
            if auto:
                for row in self.gd.RX.get(base["itype"], []):
                    lo_l = self.f.affixes.roll_auto(None, row, "min")
                    hi_l = self.f.affixes.roll_auto(None, row, "max")
                    if len(lo_l) == len(auto) and all(
                            mods[i]["stat"] == lo_l[k]["stat"] and lo_l[k]["value"] <= mods[i]["value"] <= hi_l[k]["value"]
                            for k, i in enumerate(auto)):
                        for k, i in enumerate(auto):
                            assigned[i] = (lo_l[k]["value"], hi_l[k]["value"], lo_l[k]["value"] != hi_l[k]["value"],
                                           "automagic", auto[0] if k else None)
                        # every automagic stat shares one roll per property: only the first is editable
                        break
        for i, m in enumerate(mods):
            if m.get("implicit"):
                rows.append({"where": "mods", "index": i, "stat": m.get("stat"), "value": m.get("value"),
                             "lo": m.get("value"), "hi": m.get("value"), "rolls": False, "source": "base",
                             "linked": None})
            elif i in assigned:
                lo, hi, rolls, src, linked = assigned[i]
                rows.append({"where": "mods", "index": i, "stat": m.get("stat"), "value": m.get("value"),
                             "lo": lo, "hi": hi, "rolls": rolls and linked is None, "source": src, "linked": linked})
            else:
                rows.append(self._plain("mods", i, m, "not recognised"))
        if any(r["source"] == "not recognised" for r in rows):
            notes.append("Some mods are not a game affix for this base and name: the game will mark the item Not legit.")
        return rows

    @staticmethod
    def _plain(where, i, rec, src):
        return {"where": where, "index": i, "stat": rec.get("stat"), "value": rec.get("value"),
                "lo": None, "hi": None, "rolls": False, "source": src, "linked": None}

    @staticmethod
    def _keyed(rows):
        seen = {}
        for r in rows:
            base_key = (r["where"], r["stat"])
            n = seen.get(base_key, 0)
            seen[base_key] = n + 1
            r["key"] = (r["where"], r["stat"], n)
        return rows

    # --- helpers for re-rolling ----------------------------------------------------------
    def values_by_key(self, item) -> dict:
        rows, _ = self.rows(item)
        return {r["key"]: r["value"] for r in rows}

    def reroll_job(self, item):
        """(kind, name, level, ilvl, cls, base, ethereal) to regenerate this item, or None if not possible."""
        roll = item.get("roll") if isinstance(item.get("roll"), list) else None
        ilvl = roll[2] if roll and len(roll) >= 3 else 99
        cls = roll[3] if roll and len(roll) > 3 else None
        rarity = item.get("rarity")
        level = item.get("level", ilvl) if isinstance(item.get("level"), (int, float)) else ilvl
        if rarity == "unique" and item.get("name") in self.gd.unique_defs:
            return ("unique", item["name"], level, ilvl, None, None, False)
        if rarity == "set" and item.get("name") in self.gd.set_defs:
            return ("set", item["name"], level, ilvl, None, None, False)
        if rarity == "runeword" and item.get("name") in self.gd.runeword_defs and item.get("base") in self.gd.bases:
            return ("runeword", item["name"], level, ilvl, None, item["base"], bool(item.get("ethereal")))
        if rarity in ("magic", "normal") and item.get("base") in self.gd.bases:
            return (rarity, item["base"], level, ilvl, cls, None, False)
        return None


GENERATED_KEYS = ("base", "type", "rarity", "name", "level", "ethereal", "stats", "mods", "defense", "bonus", "roll")


def replace_generated(item: dict, new: dict) -> None:
    """Overwrite the generated fields of ``item`` in place, keeping id, position and anything else."""
    for k in GENERATED_KEYS:
        if k in new:
            item[k] = new[k]
        elif k in item:
            del item[k]
