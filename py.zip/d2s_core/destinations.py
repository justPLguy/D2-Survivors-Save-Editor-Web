"""Where a generated item can go, by the game's own rules (read-only helpers + small save writers).

Ported from the game bundle:
* item ``level`` field: ``pX`` (difficulty offset, Terror tiers 105 + 8 * tier);
* hero paper doll: ``MZ`` (fits slot), ``zZ`` (can wear), ``KZ`` (weapon in the shield hand),
  ``GZ`` (two-handed), ``JZ`` / ``YZ`` (what an item pushes out), ``ZZ`` (default slot);
* mercenary doll (saveTransfer bundle): ``nu`` / ``ru`` / ``su`` and the per-type weapon kinds;
* stash tabs ``R7`` ('personal' is ``stashTabs[<class>]``), the Uniques tab ``q2`` / ``Y2``.
"""
from __future__ import annotations

HERO_SLOTS = ("weapon", "head", "amulet", "shield", "body", "gloves", "ring1", "ring2", "belt", "boots")
STASH_TABS = ("personal", "shared1", "shared2", "shared3")

# saveTransfer bundle: eu / tu / $l
MERC_WEAPONS = {"rogue": {"kinds": ["bow"]}, "desert": {"kinds": ["pole", "spea"]},
                "ironWolf": {"kinds": ["swor"], "oneHanded": True}, "barbarian": {"kinds": ["swor"]}}
MERC_CLASS_ITYPE = {"rogue": "abow"}          # a class-only base a merc may still use (Amazon bows for the Rogue)
MERC_NAMES = {"rogue": "Rogue Scout", "desert": "Desert Mercenary", "ironWolf": "Iron Wolf", "barbarian": "Barbarian"}
WIRTS_LEG = "Wirt's Leg"


def item_level(tables: dict, difficulty: str, ilvl: int, terror_tier: int = 0) -> int:
    """pX: the ``level`` the game writes on a dropped item."""
    il = tables.get("item_level") or {"offset": {"normal": -10, "nightmare": 3, "hell": 20},
                                      "terror_base": 105, "terror_step": 8}
    if terror_tier and terror_tier > 0:
        return il["terror_base"] + il["terror_step"] * terror_tier
    return max(0, ilvl + il["offset"][difficulty])


class Dolls:
    def __init__(self, gd):
        self.gd = gd

    def _base(self, item):
        return self.gd.bases.get(item.get("base"))

    # --- hero -----------------------------------------------------------------------
    def _special(self, item):
        return item.get("base") == WIRTS_LEG or item.get("type") in ("quest", "charm")

    def hero_can_wear(self, item, cls) -> bool:                       # zZ
        if self._special(item):
            return False
        b = self._base(item)
        c = b.get("cls") if b else None
        return not c or c == cls

    def two_handed(self, item, cls) -> bool:                          # GZ
        b = self._base(item)
        return bool(b and b.get("twoHand")) and not (b.get("oneOrTwo") and cls == "barbarian")

    def offhand_weapon_ok(self, item, cls) -> bool:                   # KZ
        if item.get("type") != "weapon" or not self.hero_can_wear(item, cls):
            return False
        if cls == "assassin":
            return (self._base(item) or {}).get("kind") == "claw"
        return cls == "barbarian" and not self.two_handed(item, cls)

    def hero_fits(self, item, slot, cls) -> bool:                     # MZ
        t = item.get("type")
        if t == "ring":
            return slot in ("ring1", "ring2")
        if slot == "shield" and t == "weapon":
            return bool(cls) and self.offhand_weapon_ok(item, cls)
        return slot == t

    def _pair_ok(self, weapon, other, cls) -> bool:                   # JZ
        if self.two_handed(weapon, cls):
            return False
        return other.get("type") != "weapon" or cls != "assassin" or (self._base(weapon) or {}).get("kind") == "claw"

    def hero_displaced(self, item, worn, cls, slot) -> list[str]:     # YZ
        other = "shield" if slot == "weapon" else "weapon" if slot == "shield" else None
        cur = worn.get(other) if other else None
        if not other or not cur or cur is item:
            return []
        ok = self._pair_ok(item, cur, cls) if slot == "weapon" else self._pair_ok(cur, item, cls)
        return [] if ok else [other]

    def hero_slots_for(self, item, cls) -> list[str]:
        if not self.hero_can_wear(item, cls):
            return []
        return [s for s in HERO_SLOTS if self.hero_fits(item, s, cls)]

    # --- mercenary --------------------------------------------------------------------
    def merc_slots(self, merc_type) -> list[str]:
        return ["weapon", "head", "body"] + (["shield"] if merc_type in ("ironWolf", "barbarian") else [])

    def _merc_base(self, item):
        if item.get("base") == WIRTS_LEG:
            return None
        return self._base(item)

    def _merc_weapon(self, merc_type, item) -> bool:                  # nu
        b = self._merc_base(item)
        if not b or item.get("type") != "weapon":
            return False
        if b.get("cls") and MERC_CLASS_ITYPE.get(merc_type) != b["itype"]:
            return False
        rule = MERC_WEAPONS[merc_type]
        return any(self.gd.FY(b["itype"], k) for k in rule["kinds"]) and not (rule.get("oneHanded") and b.get("twoHand"))

    def merc_fits(self, merc_type, item, slot) -> bool:               # ru
        b = self._merc_base(item)
        if not b or merc_type not in MERC_WEAPONS:
            return False
        if slot == "weapon":
            return self._merc_weapon(merc_type, item)
        if b.get("cls"):
            return False
        if slot == "head":
            return item.get("type") == "head" and self.gd.FY(b["itype"], "helm")
        if slot == "body":
            return item.get("type") == "body" and self.gd.FY(b["itype"], "tors")
        if slot == "shield":
            if merc_type == "ironWolf":
                return item.get("type") == "shield" and self.gd.FY(b["itype"], "shie")
            return merc_type == "barbarian" and self._merc_weapon(merc_type, item) and not b.get("twoHand")
        return False

    def merc_displaced(self, item, worn, slot) -> list[str]:          # su
        def both(x):
            b = self._merc_base(x) if x else None
            return bool(b and b.get("twoHand"))
        if slot == "weapon" and both(item) and worn.get("shield"):
            return ["shield"]
        if slot == "shield" and both(worn.get("weapon")):
            return ["weapon"]
        return []

    def merc_slots_for(self, merc_type, item) -> list[str]:
        return [s for s in self.merc_slots(merc_type) if self.merc_fits(merc_type, item, s)]


# --- save locations ---------------------------------------------------------------------
def stash_list(save: dict, cls: str, tab: str) -> list:
    """R7: the list behind a stash tab, created if missing."""
    key = cls if tab == "personal" else tab
    tabs = save.setdefault("stashTabs", {})
    return tabs.setdefault(key, [])


def unique_key(item: dict) -> str:                                    # H2
    return f"runeword:{item.get('name')}" if item.get("rarity") == "runeword" else item.get("name")


class UniquesTab:
    def __init__(self, tables: dict):
        self.catalog = {unique_key(e): e for e in tables.get("uniques_catalog") or []}

    def entry(self, item):                                            # q2
        if item.get("rarity") not in ("unique", "set", "runeword"):
            return None
        e = self.catalog.get(unique_key(item))
        if e and e["rarity"] == item.get("rarity") and (item.get("rarity") == "runeword" or e["base"] == item.get("base")):
            return e
        return None

    def taken(self, save, item) -> bool:
        k = unique_key(item)
        return any(unique_key(u) == k for u in save.get("uniques") or [])

    def why_not(self, save, item) -> str | None:
        if not self.entry(item):
            return "Only unique, set and runeword items from the game's list go to the Uniques tab."
        if self.taken(save, item):
            return "The Uniques tab already holds this item (the game keeps one of each)."
        return None

    def add(self, save, item) -> None:                                # Y2
        item.pop("at", None)
        save.setdefault("uniques", []).append(item)
