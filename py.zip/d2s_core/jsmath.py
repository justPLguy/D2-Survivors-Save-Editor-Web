"""JavaScript-compatible numeric helpers used by the ported D2 Survivors generators.

The game seeds ``Math.random`` with a Mulberry32 generator (``uLe`` in the game
bundle) for the duration of an item roll.  Every helper here reproduces the
exact JavaScript semantics, because a single extra or missing random draw
changes every later value of the item.
"""
from __future__ import annotations

import math


class JSRandom:
    """Mulberry32 exactly as the game's ``uLe(seed)``."""

    __slots__ = ("state",)

    def __init__(self, seed: int):
        self.state = int(seed) & 0xFFFFFFFF

    def random(self) -> float:
        self.state = (self.state + 1831565813) & 0xFFFFFFFF
        t = self.state
        t = ((t ^ (t >> 15)) * (t | 1)) & 0xFFFFFFFF
        t ^= (t + (((t ^ (t >> 7)) * (t | 61)) & 0xFFFFFFFF)) & 0xFFFFFFFF
        t &= 0xFFFFFFFF
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296.0


def js_floor(x: float) -> int:
    return math.floor(x)


def js_round(x: float) -> int:
    """``Math.round``: halves round toward +infinity (not banker's rounding)."""
    return math.floor(x + 0.5)


def num(x):
    """Return a value as JSON.stringify would print it: integral floats become ints."""
    if isinstance(x, float) and x.is_integer() and abs(x) < 2 ** 53:
        return int(x)
    return x


def randint_js(rng: JSRandom, lo: int, hi: int) -> int:
    """``e + Math.floor(Math.random() * (t - e + 1))`` (used by affix and automagic rolls)."""
    return lo + math.floor(rng.random() * (hi - lo + 1))


def jj(rng: JSRandom, lo: int, hi: int) -> int:
    """The game's ``JJ(e, t)``: ``e + floor(random * (max(e, t) - e + 1))``."""
    return lo + math.floor(rng.random() * (max(lo, hi) - lo + 1))
