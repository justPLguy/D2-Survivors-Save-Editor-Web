"""D2 Survivors editor core: save format, game-accurate item generation, inventory rules.

No GUI imports here.  Nothing in this package writes to the reference SQLite
database or to the game's files.
"""
__version__ = "9.1.0"
