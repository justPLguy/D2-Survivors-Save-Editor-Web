"""Charsi's wares: ranks, prices and bonuses exactly as the game counts them (read only - nothing here edits ranks).

Game code (moved-*.js, 2026.1101.1):
    K8(k, n)   price of normal rank n+1 = round(baseCost * (n+1)^1.5 / 10) * 10
    aqe(k, r)  price of extra rank r    = round(K8(k, maxRank-1) * (1 + r/4)^2 / 10) * 10   (endless wares, r <= 999)
    $8(k)      bonus in ranks          = ranks + sum(0.2 / sqrt(i), i = 1..extra)
    Resurrect is not sold in Hardcore.  Gold is capped at 10,000,000,000 (save check R2).
"""
from __future__ import annotations

import math

EXPONENT = 1.5        # tqe
EXTRA_DIVISOR = 4     # rqe
EXTRA_STEP = 0.2      # nqe
MAX_EXTRA = 999
GOLD_CAP = 10_000_000_000


def _round10(x: float) -> int:
    return int(math.floor(x / 10 + 0.5)) * 10      # JS Math.round(x/10)*10 for positive x


class Charsi:
    def __init__(self, wares: list[dict]):
        self.wares = list(wares)
        self.by_key = {w["key"]: w for w in self.wares}

    # --- prices --------------------------------------------------------------------------
    def normal_price(self, key: str, n: int) -> int:
        """Price of normal rank n+1 (n = ranks owned before buying)."""
        w = self.by_key[key]
        return _round10(w["baseCost"] * (n + 1) ** EXPONENT)

    def extra_price(self, key: str, r: int) -> int:
        """Price of extra rank r (1-based)."""
        w = self.by_key[key]
        return _round10(self.normal_price(key, w["maxRank"] - 1) * (1 + r / EXTRA_DIVISOR) ** 2)

    def max_level(self, key: str, hardcore: bool = False) -> int:
        w = self.by_key[key]
        if hardcore and key == "resurrect":
            return 0
        return w["maxRank"] + (MAX_EXTRA if w.get("endless") else 0)

    def level_price(self, key: str, level: int) -> int:
        """Price of overall level ``level`` (1-based: normal ranks first, then extra ranks)."""
        m = self.by_key[key]["maxRank"]
        return self.normal_price(key, level - 1) if level <= m else self.extra_price(key, level - m)

    def cost_between(self, key: str, have: int, want: int) -> int:
        """Gold to go from overall level ``have`` to ``want``."""
        return sum(self.level_price(key, lv) for lv in range(have + 1, want + 1))

    # --- a save --------------------------------------------------------------------------
    @staticmethod
    def level_of(save: dict, key: str) -> int:
        ranks = (save.get("ranks") or {}).get(key) or 0
        extra = (save.get("extraRanks") or {}).get(key) or 0
        return int(ranks) + int(extra)

    def bonus_ranks(self, key: str, level: int) -> float:
        m = self.by_key[key]["maxRank"]
        base = min(level, m)
        extra = max(0, level - m)
        return base + sum(EXTRA_STEP / math.sqrt(i) for i in range(1, extra + 1))

    def rows(self, save: dict, hardcore: bool | None = None) -> list[dict]:
        if hardcore is None:
            hardcore = save.get("mode") == "hc"
        out = []
        for w in self.wares:
            k = w["key"]
            top = self.max_level(k, hardcore)
            lv = min(self.level_of(save, k), top) if top else 0
            out.append({
                "key": k, "name": w["name"], "describe": w.get("describe", ""), "endless": w.get("endless"),
                "maxRank": w["maxRank"], "level": lv, "top": top,
                "ranks": min(lv, w["maxRank"]), "extra": max(0, lv - w["maxRank"]),
                "spent": self.cost_between(k, 0, lv),
                "next": self.level_price(k, lv + 1) if lv < top else None,
                "to_max": self.cost_between(k, lv, top),
                "bonus": self.bonus_ranks(k, lv),
                "bonus_max": self.bonus_ranks(k, top),
            })
        return out
