"""Where items live in a D2S1 save and how they occupy grids.

Grid sizes are from the D2 Survivors wiki (Items page): inventory 10x4,
Charms window 5x4, personal stash tab 10x10.  Item footprints come from the
game's own base table (``size`` = [width, height]).
"""
from __future__ import annotations

GRIDS = {
    "inventory": (10, 4),
    "charms": (5, 4),
    "stash": (10, 10),
}


def class_inventory(data: dict, cls: str, create: bool = False) -> list | None:
    root = data.get("inventoryByClass")
    if not isinstance(root, dict):
        if not create:
            return None
        root = data.setdefault("inventoryByClass", {})
    lst = root.get(cls)
    if lst is None and create:
        lst = root.setdefault(cls, [])
    return lst if isinstance(lst, list) else None


def class_charms(data: dict, cls: str, create: bool = False) -> list | None:
    root = data.get("charmsByClass")
    if not isinstance(root, dict):
        if not create:
            return None
        root = data.setdefault("charmsByClass", {})
    lst = root.get(cls)
    if lst is None and create:
        lst = root.setdefault(cls, [])
    return lst if isinstance(lst, list) else None


_SPECIAL_SIZES: dict | None = None


def _special_sizes() -> dict:
    """Sizes of items that are not in the base table (the game's NZ): quest items by code, Wirt's Leg."""
    global _SPECIAL_SIZES
    if _SPECIAL_SIZES is None:
        import json
        from pathlib import Path
        try:
            t = json.loads((Path(__file__).resolve().parent / "data" / "game_tables.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            t = {}
        quest = {k: tuple(v["size"]) for k, v in (t.get("quest_items") or {}).items()}
        wl = t.get("wirts_leg") or {"name": "Wirt's Leg", "size": [1, 3]}
        _SPECIAL_SIZES = {"quest": quest, "wirt": (wl["name"], tuple(wl["size"]))}
    return _SPECIAL_SIZES


def footprint(item: dict, bases: dict) -> tuple[int, int] | None:
    sp = _special_sizes()
    if item.get("base") == sp["wirt"][0]:
        return sp["wirt"][1]
    if item.get("type") == "quest":
        return sp["quest"].get(item.get("base"), (1, 1))
    base = bases.get(item.get("base"))
    if not base or not isinstance(base.get("size"), list):
        return None
    w, h = base["size"]
    return int(w), int(h)


def occupancy(items: list, grid: str, bases: dict):
    """Return (cells, unknown): occupied cells and items whose footprint is unknown."""
    gw, gh = GRIDS[grid]
    cells: dict[tuple[int, int], int] = {}
    unknown = []
    for idx, it in enumerate(items or []):
        at = it.get("at") if isinstance(it, dict) else None
        size = footprint(it, bases) if isinstance(it, dict) else None
        if not isinstance(at, dict) or size is None:
            unknown.append(idx)
            continue
        x, y = at.get("x"), at.get("y")
        if not isinstance(x, int) or not isinstance(y, int):
            unknown.append(idx)
            continue
        for dx in range(size[0]):
            for dy in range(size[1]):
                cells[(x + dx, y + dy)] = idx
    return cells, unknown


def fits(cells, grid: str, x: int, y: int, size: tuple[int, int]) -> bool:
    gw, gh = GRIDS[grid]
    if x < 0 or y < 0 or x + size[0] > gw or y + size[1] > gh:
        return False
    return all((x + dx, y + dy) not in cells for dx in range(size[0]) for dy in range(size[1]))


def find_free(items: list, grid: str, size: tuple[int, int], bases: dict):
    """First free top-left position, scanning columns left to right then rows; None if full.

    If an existing item's footprint is unknown, the grid is treated as unsafe and
    None is returned rather than risking an overlap.
    """
    cells, unknown = occupancy(items, grid, bases)
    if unknown:
        return None
    gw, gh = GRIDS[grid]
    for x in range(gw):
        for y in range(gh):
            if fits(cells, grid, x, y, size):
                return {"x": x, "y": y}
    return None


def collisions(items: list, grid: str, bases: dict) -> list[tuple[int, int]]:
    """Pairs of item indexes that overlap or stick out of the grid (for validation)."""
    gw, gh = GRIDS[grid]
    seen: dict[tuple[int, int], int] = {}
    bad = set()
    for idx, it in enumerate(items or []):
        at, size = it.get("at"), footprint(it, bases)
        if not isinstance(at, dict) or size is None:
            continue
        x, y = at.get("x", 0), at.get("y", 0)
        for dx in range(size[0]):
            for dy in range(size[1]):
                c = (x + dx, y + dy)
                if c[0] >= gw or c[1] >= gh:
                    bad.add((idx, idx))
                if c in seen and seen[c] != idx:
                    bad.add((seen[c], idx))
                seen[c] = idx
    return sorted(bad)


def all_item_ids(data) -> set[str]:
    out = set()

    def walk(n):
        if isinstance(n, dict):
            if isinstance(n.get("id"), str) and "base" in n and "mods" in n:
                out.add(n["id"])
            for v in n.values():
                walk(v)
        elif isinstance(n, list):
            for v in n:
                walk(v)
    walk(data)
    return out
