"""Game texts in Korean, read from the player's own D2 Survivors install (v10.9).

The editor ships no game texts.  D2 Survivors carries its Korean translation in
``resources/app.asar`` -> ``desktop/dist/web/assets/ko-<hash>.js``: one object of English text -> Korean text,
with ``#`` for numbers and ``*`` for any text.  This module finds that file on the player's disk, reads it
(read-only; nothing is written or copied) and translates the way the game's ``lang-*.js`` does (its class with
``exact``, ``templates`` and ``wilds``), so item names, stat lines and skill names read like the game in Korean.

Sources accepted by :func:`load`: the game folder (with ``resources/app.asar``), ``app.asar`` itself, an
unpacked ``app_extracted`` folder, or the ``ko-*.js`` file.
"""
from __future__ import annotations

import json
import os
import re
import struct

KO_RE = re.compile(r"(^|/)ko-[A-Za-z0-9_-]+\.js$")


# ------------------------------------------------------------------------------------------- reading
def _asar_ko(path) -> str | None:
    """``path`` is a file name or a binary file object (the web version passes the bytes the player picked)."""
    import contextlib
    cm = open(path, "rb") if isinstance(path, (str, os.PathLike)) else contextlib.nullcontext(path)
    with cm as f:
        head = f.read(16)
        if len(head) < 16:
            return None
        _a, hsize = struct.unpack("<II", head[:8])
        _b, slen = struct.unpack("<II", head[8:16])
        header = json.loads(f.read(slen).decode("utf-8"))
        base = 8 + hsize

        def walk(node, prefix=""):
            for name, n in (node.get("files") or {}).items():
                p = f"{prefix}/{name}" if prefix else name
                if "files" in n:
                    yield from walk(n, p)
                else:
                    yield p, n
        for p, n in walk(header):
            if KO_RE.search(p) and "/assets/" in f"/{p}" and not n.get("unpacked"):
                f.seek(base + int(n["offset"]))
                return f.read(int(n["size"])).decode("utf-8")
    return None


def _dir_ko(folder: str) -> str | None:
    for root, _dirs, files in os.walk(folder):
        for name in files:
            if KO_RE.search(name) and os.path.basename(root) == "assets":
                with open(os.path.join(root, name), encoding="utf-8") as f:
                    return f.read()
    return None


def find_source(path: str) -> str | None:
    """The file or folder under ``path`` that holds the Korean texts, or None."""
    if not path:
        return None
    path = os.path.normpath(os.path.expanduser(path))
    if os.path.isfile(path):
        name = os.path.basename(path).lower()
        if name.endswith(".asar") or KO_RE.search(name):
            return path
        path = os.path.dirname(path)            # e.g. "D2 Survivors.exe" was chosen
    if not os.path.isdir(path):
        return None
    for rel in (("resources", "app.asar"), ("app.asar",)):
        p = os.path.join(path, *rel)
        if os.path.isfile(p):
            return p
    for rel in (("resources", "app_extracted"), ("app_extracted",), ("desktop", "dist", "web", "assets"), ()):
        p = os.path.join(path, *rel)
        assets = os.path.join(p, "desktop", "dist", "web", "assets") if rel != ("desktop", "dist", "web", "assets") else p
        if os.path.isdir(assets) and any(KO_RE.search(n) for n in os.listdir(assets)):
            return assets
    return None


def guess_dirs() -> list[str]:
    """Usual places of a D2 Survivors install on Windows (checked in this order)."""
    out = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        out += [os.path.join(local, "Programs", n) for n in ("D2 Survivors", "d2-survivors", "d2survivors")]
    for env in ("PROGRAMFILES", "PROGRAMFILES(X86)"):
        if os.environ.get(env):
            out.append(os.path.join(os.environ[env], "D2 Survivors"))
    for drive in "CDEFG":
        out += [f"{drive}:\\D2 Survivors", f"{drive}:\\d2 survivors", f"{drive}:\\Games\\D2 Survivors"]
    return out


def read_text(source: str) -> str | None:
    if source.lower().endswith(".asar"):
        return _asar_ko(source)
    if os.path.isdir(source):
        return _dir_ko(source)
    with open(source, encoding="utf-8") as f:
        return f.read()


_ESC = {"n": "\n", "t": "\t", "r": "\r", "`": "`", "\\": "\\", "'": "'", '"': '"', "$": "$", "0": "\0"}


def _string(js: str, i: int) -> tuple[str, int]:
    """A JS string literal ('…', "…" or `…` without ${}) starting at i -> (text, index after it)."""
    q = js[i]
    buf = []
    i += 1
    while js[i] != q:
        ch = js[i]
        if ch == "\\":
            nx = js[i + 1]
            if nx == "u":
                if js[i + 2] == "{":
                    end = js.index("}", i)
                    buf.append(chr(int(js[i + 3:end], 16)))
                    i = end + 1
                else:
                    buf.append(chr(int(js[i + 2:i + 6], 16)))
                    i += 6
                continue
            if nx == "x":
                buf.append(chr(int(js[i + 2:i + 4], 16)))
                i += 4
                continue
            if nx == "\n":
                i += 2
                continue
            buf.append(_ESC.get(nx, nx))
            i += 2
            continue
        if q == "`" and ch == "$" and js[i + 1] == "{":
            raise ValueError("template expression in the Korean texts")
        buf.append(ch)
        i += 1
    return "".join(buf), i + 1


_IDENT = re.compile(r"[A-Za-z0-9_$]+")


def parse_module(js: str) -> dict[str, str]:
    """``var e={"English":`한국어`,...};export{e as default};`` -> dict."""
    i = js.index("{") + 1
    out: dict[str, str] = {}
    n = len(js)
    while i < n:
        while i < n and js[i] in " \n\r\t,":
            i += 1
        if i >= n or js[i] == "}":
            break
        if js[i] in "\"'`":
            key, i = _string(js, i)
        else:
            m = _IDENT.match(js, i)
            if not m:
                raise ValueError(f"unexpected {js[i]!r} at {i}")
            key, i = m.group(0), m.end()
        if js[i] != ":":
            raise ValueError(f"':' expected at {i}")
        i += 1
        if js[i] not in "\"'`":
            raise ValueError(f"string expected at {i}")
        out[key], i = _string(js, i)
    return out


# ---------------------------------------------------------------------------------------- translating
def _norm(t: str) -> str:                                                    # s()
    return re.sub(r"\s+", " ", t).strip().upper()


_NUM = re.compile(r"(?<![^\W_])(?<![.,])\d+(?:[.,]\d+)*")                     # c


def _numbers(t: str):                                                        # l()
    nums = []

    def sub(m):
        nums.append(m.group(0))
        return "#"
    return _NUM.sub(sub, t), nums


_U = r"[+-]?(?:\(\d[\d,.]*\s*[-–]\s*\d[\d,.]*\)|\d[\d,.]*(?:\s*[-–]\s*\d[\d,.]*)?)%?"
_LEAD = re.compile(rf"^({_U})\s+(.+)$", re.S)                                # d
_TAIL = re.compile(rf"^(.+?)\s+({_U})$", re.S)                               # f
_HANGUL = re.compile(r"[가-힣ㄱ-ㆎ]")                                          # p
_LATIN = re.compile(r"[A-Za-z]")                                             # m
_SLOT = re.compile(r"\{(\d+)\}")
_PUNCT = re.compile(r"^(.*[A-Za-z)])([,.;:!?]+)$", re.S)
_TO = re.compile(r"^to (.+)$", re.I | re.S)


class _Wild:
    __slots__ = ("pattern", "clue", "fixed", "list", "translated")


def _wild(key: str, translated: str, group: str = "(.*?)"):                  # g()
    parts = key.split("*")
    if len(re.findall(r"[A-Z]", "".join(parts))) < 3:
        return None
    w = _Wild()
    w.pattern = re.compile("^" + group.join(re.escape(p).replace(r"\ ", " ").replace(" ", r"\s+") for p in parts) + "$",
                           re.I | re.S)
    clue = ""
    for p in parts:
        if len(p.strip()) > len(clue):
            clue = p.strip()
    w.clue = clue
    w.fixed = len(re.sub(r"\s", "", "".join(parts)))
    w.list = " · " in key
    w.translated = translated
    return w


class GameTranslator:
    """The game's translator (lang-*.js class ``_``) on one catalog."""

    def __init__(self, catalog: dict[str, str]):
        self.exact: dict[str, str] = {}
        self.templates: dict[str, str] = {}
        wilds = []
        for k, v in catalog.items():
            if not v:
                continue
            t = _norm(k)
            if "*" in t:
                w = _wild(t, v)
                if w:
                    wilds.append(w)
            elif "#" in t:
                self.templates[t] = v
                w = _wild(t.replace("#", "*"), v, r"([+-]?\d.*?)")
                if w:
                    wilds.append(w)
            else:
                self.exact[t] = v
        wilds.reverse()
        wilds.sort(key=lambda w: -w.fixed)                                    # stable, like Array.sort
        self.wilds = wilds
        self.cache: dict[str, str] = {}

    def __len__(self):
        return len(self.exact) + len(self.templates) + len(self.wilds)

    def translate_as(self, kind: str, text: str) -> str:
        hit = self.exact.get(_norm(f"{kind}:{text.strip()}"))
        return hit if hit is not None else self.translate(text)

    def translate_magic(self, name: str, base: str) -> str:
        at = -1
        r = name.find(base)
        while r >= 0:
            rest = name[r + len(base):]
            if (r == 0 or name[r - 1] == " ") and (rest == "" or rest.startswith(" ")):
                at = r
                break
            r = name.find(base, r + 1)
        if at < 0:
            return self.translate(name)
        pre, suf = name[:at].strip(), name[at + len(base):].strip()
        parts = [self.translate_as("affix", suf) if suf else "", self.translate_as("affix", pre) if pre else "",
                 self.translate_as("item", base)]
        return " ".join(p for p in parts if p)

    def item_name(self, item: dict) -> str:
        """The name as the game shows it (lang ``I``): rare names stay, magic names are built from their parts."""
        name = item.get("name") or ""
        rar = item.get("rarity")
        if rar == "rare":
            return name
        if rar == "magic":
            return self.translate_magic(name, item.get("base") or "") if item.get("base") else name
        return self.translate_as("item", name)

    def translate(self, text: str) -> str:
        if not text or not _LATIN.search(text):
            return text
        hit = self.cache.get(text)
        if hit is not None:
            return hit
        found = self.find(text, 0)
        out = text if found is None else found
        if len(self.cache) > 20000:
            self.cache.clear()
        self.cache[text] = out
        return out

    def find(self, text: str, depth: int):
        core = text.strip()
        if not core or not _LATIN.search(core):
            return None
        r = self.lookup(core, depth)
        if r is None:
            return None
        if "\n" not in text:
            r = re.sub(r"\s*\n\s*", " ", r)
        at = text.index(core)
        return text[:at] + r + text[at + len(core):]

    def lookup(self, e: str, depth: int):
        n = _norm(e)
        r = self.exact.get(n)
        if r is not None:
            return r
        tpl, nums = _numbers(e)
        if nums:
            hit = self.templates.get(_norm(tpl))
            if hit is not None:
                return _SLOT.sub(lambda m: nums[int(m.group(1))] if int(m.group(1)) < len(nums) else m.group(0), hit)
        if depth > 3:
            return None

        def sub(x):
            return self.find(x, depth + 1)
        fallback = None
        for w in self.wilds:
            if w.clue not in n:
                continue
            m = w.pattern.match(e)
            if not m or (not w.list and any(" · " in (g or "") for g in m.groups())):
                continue
            ok = True

            def fill(mm):
                nonlocal ok
                k = int(mm.group(1)) + 1
                if k > len(m.groups()):
                    return mm.group(0)
                val = m.group(k) or ""
                t = sub(val)
                if t is None and _LATIN.search(val):
                    ok = False
                return val if t is None else t
            out = _SLOT.sub(fill, w.translated)
            if ok:
                return out
            if fallback is None:
                fallback = out
        if "\n" in e:
            lines = e.split("\n")
            got = [sub(x) for x in lines]
            if any(g is not None for g in got):
                return "\n".join(g if g is not None else x for x, g in zip(lines, got))
        m = _PUNCT.match(e)
        if m:
            t = sub(m.group(1))
            if t is not None:
                return t + m.group(2)
        for sep in (" · ", " / ", " - "):
            if sep not in e:
                continue
            parts = e.split(sep)
            got = [sub(x) for x in parts]
            if any(g is not None for g in got):
                return sep.join(g if g is not None else x for x, g in zip(parts, got))
        p = e.find(": ")
        if p > 0:
            t = sub(e[:p + 1])
            if t is None:
                t = sub(e[:p])
            if t is not None:
                rest = e[p + 2:]
                rt = sub(rest)
                return re.sub(r":?\s*$", ":", t, count=1) + " " + (rest if rt is None else rt)
        m = _TO.match(e)
        if m:
            t = sub(m.group(1))
            if t is not None:
                return t
        m = _LEAD.match(e)
        if m:
            t = sub(m.group(2))
            if t is not None:
                return f"{m.group(1)} {t}"
        m = _TAIL.match(e)
        if m:
            t = sub(m.group(1))
            if t is not None:
                return f"{t} {m.group(2)}"
        return fallback


def from_bytes(data: bytes) -> tuple[GameTranslator | None, str]:
    """The web version: the bytes of ``app.asar`` or of ``ko-*.js`` that the player picked in the browser."""
    import io
    try:
        if data[:4] == b"\x04\x00\x00\x00":
            js = _asar_ko(io.BytesIO(data))
        else:
            js = data.decode("utf-8")
        if not js:
            return None, "This D2 Survivors build has no Korean texts."
        cat = parse_module(js)
    except Exception as exc:                                                # noqa: BLE001
        return None, f"Could not read the Korean texts: {exc}"
    return GameTranslator(cat), f"{len(cat)} Korean game texts read"


def load(path: str) -> tuple[GameTranslator | None, str]:
    """(translator, message).  ``path`` is what the player chose; nothing on disk is changed."""
    src = find_source(path)
    if not src:
        return None, "No D2 Survivors files with Korean texts were found there (looked for resources/app.asar)."
    try:
        js = read_text(src)
        if not js:
            return None, "This D2 Survivors build has no Korean texts."
        cat = parse_module(js)
    except Exception as exc:                                                # noqa: BLE001
        return None, f"Could not read the Korean texts: {exc}"
    t = GameTranslator(cat)
    return t, f"{len(cat)} Korean game texts read from {src}"


def autodetect(saved: str | None = None) -> tuple[GameTranslator | None, str, str | None]:
    """Try the saved folder, then the usual install places.  Returns (translator, message, folder used)."""
    for d in ([saved] if saved else []) + guess_dirs():
        if d and find_source(d):
            t, msg = load(d)
            if t:
                return t, msg, d
    return None, "D2 Survivors was not found.", None
