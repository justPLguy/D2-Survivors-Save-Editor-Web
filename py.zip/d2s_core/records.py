"""Item-record checks the game runs when it reads a save (port of the game's SZ/TZ/CZ).

If any of these fail, the game silently drops the item on load ("an item the
game no longer reads"), so the editor refuses to export such a record.
"""
from __future__ import annotations

import re

ID_RE = re.compile(r"^[\w-]{1,32}$", re.ASCII)   # JS \w is ASCII-only
NAME_RE = re.compile(r"^[A-Za-z' -]{1,64}$")
STAT_RE = re.compile(r"^[a-z0-9_]{1,48}$")
INT_MOD_STATS = {"enhancedDefense", "mana"}
POISON_DAMAGE = "poisonDamage"


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _small_int(v, limit=1000):  # the game's wZ
    return isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= limit


def known_mod(gd, stat: str) -> bool:  # the game's VRe
    if not isinstance(stat, str):
        return False
    if stat in gd.HX:
        return True
    m = re.fullmatch(r"skilltab(\d+)", stat)
    if m:
        n = int(m.group(1))
        return n // 3 < len(gd.Fi)
    m = re.fullmatch(r"classskills(\d)", stat)
    return bool(m) and int(m.group(1)) < len(gd.Fi)


def record_problems(item: dict, gd) -> list[str]:
    """Return why the game would refuse to read this item record (empty list = readable)."""
    p = []
    if not isinstance(item, dict):
        return ["not an object"]
    lim = gd.limits
    if item.get("type") == "quest":
        return p
    if item.get("base") == "Wirt's Leg":            # the game's own special case in SZ
        ok = (isinstance(item.get("id"), str) and ID_RE.match(item["id"]) and item.get("name") == "Wirt's Leg"
              and item.get("rarity") == "unique" and item.get("type") == "weapon" and item.get("mods") == []
              and "stats" not in item and "defense" not in item and item.get("level") == 0)
        return [] if ok else ["Wirt's Leg must be the plain quest weapon (no mods, level 0)"]
    base = gd.bases.get(item.get("base"))
    if not base:
        p.append(f"unknown base {item.get('base')!r}")
        return p
    if item.get("type") != base["type"]:
        p.append(f"type {item.get('type')!r} is not the base's type {base['type']!r}")
    rarity = item.get("rarity")
    if rarity not in gd.XX:
        p.append(f"unknown rarity {rarity!r}")
    if not isinstance(item.get("id"), str) or not ID_RE.match(item["id"]):
        p.append("id must be 1-32 letters, digits, _ or -")
    if not isinstance(item.get("name"), str) or not NAME_RE.match(item["name"]):
        p.append("name may only contain letters, spaces, ' and - (max 64)")
    lvl = item.get("level")
    if not _is_num(lvl) or lvl < 0:
        p.append("level must be a number >= 0")
    mods = item.get("mods")
    if not isinstance(mods, list):
        p.append("mods must be a list")
        mods = []
    stats = item.get("stats")
    if stats is not None:
        if not isinstance(stats, list) or len(stats) > lim["max_stats"]:
            p.append(f"stats must be a list of at most {lim['max_stats']}")
        else:
            for s in stats:
                if not isinstance(s, dict) or not isinstance(s.get("stat"), str) or not STAT_RE.match(s["stat"]):
                    p.append(f"bad stat record {s!r}")
                    continue
                v = s.get("value")
                if not isinstance(v, int) or isinstance(v, bool) or abs(v) > lim["stat_abs_max"]:
                    p.append(f"{s['stat']}: value must be a whole number within ±{lim['stat_abs_max']}")
                for k in ("param", "level"):
                    if k in s and not _small_int(s[k]):
                        p.append(f"{s['stat']}: {k} must be a whole number 0..1000")
        if rarity not in ("unique", "set", "runeword"):
            p.append("stats are only allowed on unique, set and runeword items")
    if "ethereal" in item and (item["ethereal"] is not True or rarity != "runeword"):
        p.append("ethereal is only allowed (as true) on runewords")
    if "bonus" in item and (rarity != "set" or stats is None):
        p.append("bonus is only allowed on set items with stats")
    if "defense" in item and not _small_int(item["defense"]):
        p.append("defense must be a whole number 0..1000")
    if stats is None:
        counts = {"affix": 0, "auto": 0, "implicit": 0}
        poison_min = poison_max = 0
        for m in mods:
            if not isinstance(m, dict):
                p.append("mod is not an object")
                continue
            st, v = m.get("stat"), m.get("value")
            if not (known_mod(gd, st) or st == POISON_DAMAGE):
                p.append(f"{st}: a mod the game does not know")
            if not _is_num(v) or abs(v) > lim["stat_abs_max"]:
                p.append(f"{st}: value must be a number within ±{lim['stat_abs_max']}")
                continue
            kind = "implicit" if m.get("implicit") else "auto" if m.get("auto") else "affix"
            counts[kind] += 1
            needs_len = st in ("poisonMinDamage", POISON_DAMAGE)
            if needs_len != ("length" in m):
                p.append(f"{st}: length is required exactly on poison damage")
            if needs_len and not (_small_int(m.get("length")) and 0 < m["length"] <= lim["poison_length_max"]):
                p.append(f"{st}: bad poison length")
            if (needs_len or st == "poisonMaxDamage") and v < 0:
                p.append(f"{st}: negative poison damage")
            if st in INT_MOD_STATS and not _small_int(v):
                p.append(f"{st}: must be a whole number 0..1000")
            poison_min += st == "poisonMinDamage"
            poison_max += st == "poisonMaxDamage"
        for kind in counts:
            if counts[kind] > lim[kind]:
                p.append(f"too many {kind} mods ({counts[kind]} > {lim[kind]})")
        if poison_min != poison_max:
            p.append("poisonMinDamage and poisonMaxDamage must come in pairs")
    return p


def record_warnings(item: dict, gd) -> list[str]:
    """Non-fatal: the game still reads the item but drops the field (e.g. a bad position)."""
    w = []
    at = item.get("at") if isinstance(item, dict) else None
    lim = gd.limits
    if at is not None and not (isinstance(at, dict) and _small_int(at.get("x")) and _small_int(at.get("y"))
                               and at["x"] < lim["grid_coord_max"] and at["y"] < lim["grid_coord_max"]):
        w.append("position (at) is outside 0..9 and will be dropped by the game")
    return w
