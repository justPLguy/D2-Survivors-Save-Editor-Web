"""Item designs (inventory pictures) - which picture the game shows for an item.

Game code (bundle Game-*.js):
    icon = uniqueIcons[name] (unique) / setIcons[name] (set) / icons[base][yBe(id) % icons[base].length]
    yBe(id): t = 0; for each character: t = (t*31 + charCode) >>> 0
The picture lists come from the player's Diablo II files (desktop extract-worker.cjs):
    rings 5 pictures, amulets 3 (VARIANTS = {rin: 5, amu: 3});
    charms: itemtypes.txt VarInvGfx for scha / mcha / lcha (3 each in Diablo II).
Every other base has one picture, so its look cannot change.
The design is chosen only through the item id: the roll and the stats stay the same.
"""
from __future__ import annotations

from typing import Iterable

DESIGNS = {"Ring": 5, "Amulet": 3, "Small Charm": 3, "Large Charm": 3, "Grand Charm": 3}


def id_hash(item_id: str) -> int:
    """yBe: the game's 31-hash of the id (unsigned 32-bit)."""
    t = 0
    for ch in item_id:
        t = (t * 31 + ord(ch)) & 0xFFFFFFFF
    return t


def design_count(item: dict) -> int:
    """How many designs the game can show for this item (0 = the look is fixed)."""
    if not isinstance(item, dict) or item.get("rarity") in ("unique", "set"):
        return 0
    n = DESIGNS.get(item.get("base"), 0)
    return n if n > 1 else 0


def design_of(item: dict) -> int | None:
    """1-based design number the game shows now, or None when the look is fixed."""
    n = design_count(item)
    if not n or not isinstance(item.get("id"), str):
        return None
    return id_hash(item["id"]) % n + 1


def id_for_design(count: int, design: int, existing: Iterable[str] = ()) -> str:
    """A new, unused id that makes the game show ``design`` (1-based) out of ``count`` pictures."""
    from .itemgen.api import new_item_id
    taken = set(existing)
    while True:
        value = new_item_id(taken)
        if id_hash(value) % count == design - 1:
            return value
        taken.add(value)


def picture_files(base: str, d2_dir=None) -> list:
    """Paths of the design pictures the game extracted for ``base`` (from the player's own Diablo II files).

    Reads ``%APPDATA%\\D2 Survivors\\d2\\items.json`` (bases[base].inv); empty when the game has not
    extracted them on this computer.  Read only.
    """
    import json
    import os
    from pathlib import Path
    if d2_dir is None:
        appdata = os.environ.get("APPDATA")
        if not appdata:
            return []
        d2_dir = Path(appdata) / "D2 Survivors" / "d2"
    d2_dir = Path(d2_dir)
    global _MANIFEST
    try:
        if _MANIFEST is None or _MANIFEST[0] != d2_dir:
            _MANIFEST = (d2_dir, json.loads((d2_dir / "items.json").read_text(encoding="utf-8")))
        inv = (_MANIFEST[1].get("bases", {}).get(base) or {}).get("inv") or []
    except Exception:
        return []
    out = [d2_dir / e["file"] for e in inv if isinstance(e, dict) and e.get("file")]
    return out if all(p.is_file() for p in out) else []


_MANIFEST = None
