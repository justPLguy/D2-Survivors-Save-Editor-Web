"""Hero build checks, ported from the game (bundle functions I2, L2, Y0, q0).

The game runs these on every save it loads for the leaderboard; a build that fails one
is reported by name.  Limits come from ``game_tables.json`` (exported from the game):
``skills_active`` (max level per class skill), ``passives_shared`` / ``passives_class``
(max level per passive) and ``stat_points_q0`` (stat points earned by level, Hell).

Read-only: nothing here changes the save.
"""
from __future__ import annotations

STAT_POINT_SLACK = 15000      # the game allows q0(level) + 15000 points
DEFAULT_SLOTS = 6
TREE_PICK_MAX = 3


def iter_builds(save: dict):
    """(cls, where, entry) for every build the game checks (L2): heroes[cls].kept/.run, retired[cls][n].kept/.run."""
    for cls, hero in (save.get("heroes") or {}).items():
        if not isinstance(hero, dict):
            continue
        for part in ("kept", "run"):
            if isinstance(hero.get(part), dict):
                yield cls, f"heroes.{cls}.{part}", hero[part]
    for cls, rows in (save.get("retired") or {}).items():
        for n, row in enumerate(rows or []):
            if not isinstance(row, dict):
                continue
            for part in ("kept", "run"):
                if isinstance(row.get(part), dict):
                    yield cls, f"retired.{cls}[{n}].{part}", row[part]


def stat_points(build: dict) -> int:
    """Y0: unspent + 5 per 'attribute:' pick + 1 per 'point:' pick."""
    total = build.get("unspent") or 0
    for h in build.get("history") or []:
        if isinstance(h, str):
            if h.startswith("attribute:"):
                total += 5
            elif h.startswith("point:"):
                total += 1
    return total


class BuildRules:
    def __init__(self, tables: dict):
        self.active: dict[str, dict[str, int]] = tables["skills_active"]
        self.shared: dict[str, int] = tables["passives_shared"]
        self.cls_passives: dict[str, dict[str, int]] = tables["passives_class"]
        self.q0 = {int(k): v for k, v in tables["stat_points_q0"].items()}

    def passives_for(self, cls: str) -> dict[str, int]:
        return {**self.shared, **(self.cls_passives.get(cls) or {})}

    def stat_point_cap(self, level: int) -> int:
        return self.q0.get(level, 5 * max(0, level - 1) + 10) + STAT_POINT_SLACK

    def problem(self, cls: str, entry: dict) -> str | None:
        """The game's I2: first problem as the game words it, or None."""
        b = entry.get("build")
        if not isinstance(b, dict):
            return f"{cls}: no build"
        lvl = b.get("level")
        if not isinstance(lvl, int) or isinstance(lvl, bool) or lvl < 1 or lvl > 99:
            return f"{cls}: level {lvl}"
        active = self.active.get(cls) or {}
        passive = self.passives_for(cls)
        slots = b.get("slots")
        slots = DEFAULT_SLOTS if slots is None else slots
        skills = b.get("skills") or []
        for s in skills:
            sid = s.get("id")
            if sid not in active:
                return f"{cls}: {sid}, not her class's"
            if (s.get("level") or 0) > active[sid]:
                return f"{cls}: {sid} at level {s.get('level')}"
        passives = b.get("passives") or {}
        for pid, lv in passives.items():
            if lv:
                if pid not in passive:
                    return f"{cls}: {pid}, not her class's"
                if lv > passive[pid]:
                    return f"{cls}: {pid} at level {lv}"
        used = sum(1 for v in passives.values() if (v or 0) > 0)
        if len(skills) > slots or used > slots:
            return f"{cls}: more skills or passives than her {slots} slots"
        if any(t > TREE_PICK_MAX for t in (b.get("trees") or [])):
            return f"{cls}: more than 3 picks on a tree"
        pts = stat_points(b)
        if pts > self.stat_point_cap(lvl):
            return f"{cls}: {pts} stat points at level {lvl}"
        return None

    def check_save(self, save: dict) -> list[tuple[str, str]]:
        """[(where, problem)] for every build the game would reject."""
        out = []
        for cls, where, entry in iter_builds(save):
            p = self.problem(cls, entry)
            if p:
                out.append((where, p))
        return out

    def slots_info(self, build: dict) -> tuple[int, int, int]:
        """(skills used, passives used, slots)."""
        slots = build.get("slots")
        slots = DEFAULT_SLOTS if slots is None else slots
        skills = len(build.get("skills") or [])
        passives = sum(1 for v in (build.get("passives") or {}).values() if (v or 0) > 0)
        return skills, passives, slots
