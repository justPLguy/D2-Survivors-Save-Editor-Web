"""Every place the game keeps item records in a save."""
from __future__ import annotations


def iter_save_items(data):
    """(where, item) for every item record in the places the game keeps items."""
    def lists(root, label):
        if isinstance(root, dict):
            for k, v in root.items():
                if isinstance(v, list):
                    for it in v:
                        if isinstance(it, dict):
                            yield f"{label}/{k}", it
    yield from lists(data.get("inventoryByClass"), "inventory")
    yield from lists(data.get("charmsByClass"), "charms")
    yield from lists(data.get("stashTabs"), "stash")
    for cls, slots in (data.get("equippedByClass") or {}).items():
        if isinstance(slots, dict):
            for slot, it in slots.items():
                if isinstance(it, dict):
                    yield f"equipped/{cls}/{slot}", it
    for cls, own in (data.get("mercs") or {}).items():
        for mt, merc in ((own or {}).get("hired") or {}).items() if isinstance(own, dict) else ():
            worn = merc.get("worn") if isinstance(merc, dict) else None
            if isinstance(worn, dict):
                for slot, it in worn.items():
                    if isinstance(it, dict):
                        yield f"mercenary/{cls}/{mt}/{slot}", it
    for it in data.get("uniques") or []:
        if isinstance(it, dict):
            yield "uniques tab", it
