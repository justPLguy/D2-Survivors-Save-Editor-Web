"""Every place the game keeps item records in a save."""
from __future__ import annotations


def iter_save_items(data):
    """(where, item) for every item record in the places the game keeps items."""
    def lists(root, label):
        if isinstance(root, dict):
            for k, v in root.items():
                if isinstance(v, list):
                    for it in v:
                        if isinstance(it, dict):
                            yield f"{label}/{k}", it
    yield from lists(data.get("inventoryByClass"), "inventory")
    yield from lists(data.get("charmsByClass"), "charms")
    yield from lists(data.get("stashTabs"), "stash")
    for cls, slots in (data.get("equippedByClass") or {}).items():
        if isinstance(slots, dict):
            for slot, it in slots.items():
                if isinstance(it, dict):
                    yield f"equipped/{cls}/{slot}", it
    for cls, ws in (data.get("weaponSets") or {}).items():          # game 2026.1102.1: the set not in hand
        if isinstance(ws, dict):
            for slot in ("weapon", "shield"):
                it = ws.get(slot)
                if isinstance(it, dict):
                    yield f"equipped/{cls}/{slot} (other weapon set)", it
    for cls, own in (data.get("mercs") or {}).items():
        for mt, merc in ((own or {}).get("hired") or {}).items() if isinstance(own, dict) else ():
            worn = merc.get("worn") if isinstance(merc, dict) else None
            if isinstance(worn, dict):
                for slot, it in worn.items():
                    if isinstance(it, dict):
                        yield f"mercenary/{cls}/{mt}/{slot}", it
    for it in data.get("uniques") or []:
        if isinstance(it, dict):
            yield "uniques tab", it


# --- weapon sets (game 2026.1102.1: bZ / xZ / cYe / SZ / $8e) -----------------------------------------
WEAPON_SET_SLOTS = ("weapon", "shield")
SAVE_VERSION_WITH_SETS = 15      # Q8e: the game writes 15 only when a second weapon set holds an item
SAVE_VERSION_BASE = 14           # r9


def active_set(data, cls) -> int:
    """bZ: the weapon set in the hero's hands (1 or 2)."""
    ws = (data.get("weaponSets") or {}).get(cls)
    return 2 if isinstance(ws, dict) and ws.get("active") == 2 else 1


def other_set(data, cls) -> int:
    return 2 if active_set(data, cls) == 1 else 1


def set_holder(data, cls, n, create=False):
    """The dict that holds weapon set ``n`` of a hero: equippedByClass (in hand) or weaponSets (the other)."""
    if active_set(data, cls) == n:
        root = data.setdefault("equippedByClass", {}) if create else (data.get("equippedByClass") or {})
        return root.setdefault(cls, {}) if create else root.get(cls)
    if create:
        sets = data.setdefault("weaponSets", {})
        return sets.setdefault(cls, {"active": active_set(data, cls)})
    return (data.get("weaponSets") or {}).get(cls)


def set_items(data):
    """SZ: every item in a weapon set that is not in hand."""
    out = []
    for ws in (data.get("weaponSets") or {}).values():
        if isinstance(ws, dict):
            out += [ws[s] for s in WEAPON_SET_SLOTS if isinstance(ws.get(s), dict)]
    return out


def tidy_weapon_sets(data):
    """dYe + $8e: drop empty set-1 entries and give the save the version the game writes for it."""
    sets = data.get("weaponSets")
    if isinstance(sets, dict):
        for cls in list(sets):
            ws = sets[cls]
            if isinstance(ws, dict) and ws.get("active", 1) == 1 and not any(ws.get(s) for s in WEAPON_SET_SLOTS):
                del sets[cls]
        if not sets:
            del data["weaponSets"]
    v = data.get("version")
    if isinstance(v, int):
        if set_items(data) and v < SAVE_VERSION_WITH_SETS:
            data["version"] = SAVE_VERSION_WITH_SETS
        elif not set_items(data) and v == SAVE_VERSION_WITH_SETS:
            data["version"] = SAVE_VERSION_BASE
