"""D2S1 save-code format.

``decode_save`` and ``encode_save`` are moved here unchanged from
D2-Survivors-Save-Editor-v9.0.py.  The only addition is ``allow_nan=False``:
JSON.parse in the game rejects NaN/Infinity, so such a value must never reach
an exported code.  For any valid save the output is byte-identical to v9.0.
"""
from __future__ import annotations

import base64
import copy
import json
import zlib

PREFIX = "D2S1:"


def decode_save(save_code: str):
    save_code = save_code.strip()
    if not save_code.startswith(PREFIX):
        raise ValueError("The save code must start with D2S1:")
    encoded = save_code[len(PREFIX):]
    encoded += "=" * (-len(encoded) % 4)
    raw = zlib.decompress(base64.urlsafe_b64decode(encoded))
    return json.loads(raw.decode("utf-8"))


def encode_save(data) -> str:
    raw = json.dumps(data, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    encoded = base64.urlsafe_b64encode(zlib.compress(raw, level=9)).decode("ascii").rstrip("=")
    return PREFIX + encoded


def verify_roundtrip(data) -> str:
    """Encode ``data`` and prove the code decodes back to exactly the same JSON.

    Returns the code.  Raises ``ValueError`` if anything (including key order)
    would change, so an export can be stopped before a damaged code is shown.
    """
    code = encode_save(data)
    back = decode_save(code)
    a = json.dumps(data, separators=(",", ":"), ensure_ascii=False)
    b = json.dumps(back, separators=(",", ":"), ensure_ascii=False)
    if a != b:
        raise ValueError("Round-trip check failed: the encoded save does not decode to the same data.")
    return code


def changed_paths(before, after, path=()):
    """List JSON paths whose value differs between two decoded saves (order-sensitive for lists)."""
    out = []
    if isinstance(before, dict) and isinstance(after, dict):
        for key in list(before.keys()) + [k for k in after.keys() if k not in before]:
            if key not in before or key not in after:
                out.append(path + (key,))
            else:
                out.extend(changed_paths(before[key], after[key], path + (key,)))
    elif isinstance(before, list) and isinstance(after, list):
        for i in range(max(len(before), len(after))):
            if i >= len(before) or i >= len(after):
                out.append(path + (i,))
            else:
                out.extend(changed_paths(before[i], after[i], path + (i,)))
    elif type(before) is not type(after) or before != after:
        out.append(path)
    return out


def deep_copy(data):
    return copy.deepcopy(data)
